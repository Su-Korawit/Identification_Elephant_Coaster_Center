# src/elephant_vision/train_reid.py
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

from elephant_vision.reid_model import ElephantReIDModel
from elephant_vision.reid_dataset import get_reid_dataloaders

def train_reid(
    data_dir="artifacts/datasets/reid/train",
    epochs=3,
    batch_size=4,
    lr=1e-4,
    weight_decay=1e-4,
    patience=5,  # early stopping patience
):

    device = "cuda" if torch.cuda.is_available() else "cpu"

    train_loader, val_loader, full_dataset = get_reid_dataloaders(
        data_dir=data_dir,
        batch_size=batch_size,
        num_workers=2,
        val_ratio=0.2,
    )

    num_classes = len(full_dataset.classes)
    print(f"📦 Found {num_classes} elephant identities: {full_dataset.classes}")

    model = ElephantReIDModel(num_classes=num_classes).to(device)

    criterion = nn.CrossEntropyLoss()

    # 🔒 ใช้ AdamW + weight decay = L2 regularization
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    # ลด lr ถ้า val loss ไม่ดีขึ้น
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=2, verbose=True
    )

    history = {
        "train_loss": [],
        "val_loss": [],
        "train_acc": [],
        "val_acc": [],
    }

    best_val_loss = float("inf")
    bad_epochs = 0
    best_state_dict = None

    for epoch in range(epochs):
        # =========================
        # 🔁 TRAIN PHASE
        # =========================
        model.train()
        total_loss, correct, total = 0.0, 0, 0

        for imgs, labels in train_loader:
            imgs, labels = imgs.to(device), labels.to(device)

            _, logits = model(imgs)
            loss = criterion(logits, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            preds = torch.argmax(logits, dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

        avg_train_loss = total_loss / len(train_loader)
        train_acc = correct / total * 100.0

        # =========================
        # 🧪 VAL PHASE
        # =========================
        model.eval()
        val_total_loss, val_correct, val_total = 0.0, 0, 0

        with torch.no_grad():
            for imgs, labels in val_loader:
                imgs, labels = imgs.to(device), labels.to(device)
                _, logits = model(imgs)
                loss = criterion(logits, labels)

                val_total_loss += loss.item()
                preds = torch.argmax(logits, dim=1)
                val_correct += (preds == labels).sum().item()
                val_total += labels.size(0)

        avg_val_loss = val_total_loss / len(val_loader)
        val_acc = val_correct / val_total * 100.0

        # =========================
        # 💾 LOGGING
        # =========================
        history["train_loss"].append(avg_train_loss)
        history["val_loss"].append(avg_val_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)

        print(f"Epoch [{epoch+1}/{epochs}] "
              f"- Train Loss: {avg_train_loss:.4f} | Train Acc: {train_acc:.2f}% "
              f"- Val Loss: {avg_val_loss:.4f} | Val Acc: {val_acc:.2f}%")

        # =========================
        # 📉 SCHEDULER STEP
        # =========================
        scheduler.step(avg_val_loss)

        # =========================
        # 🛑 EARLY STOPPING
        # =========================
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            best_state_dict = model.state_dict()
            bad_epochs = 0
        else:
            bad_epochs += 1
            if bad_epochs >= patience:
                print("🛑 Early stopping triggered.")
                break

    # =========================
    # 💾 SAVE BEST MODEL
    # =========================
    os.makedirs("artifacts/models", exist_ok=True)
    best_model_path = "artifacts/models/reid_model.pt"
    torch.save(best_state_dict, best_model_path)
    print(f"✅ Best model saved to {best_model_path}")

    # =========================
    # 📊 PLOT
    # =========================
    os.makedirs("artifacts/plots", exist_ok=True)

    plt.figure(figsize=(10,4))

    # Loss
    plt.subplot(1,2,1)
    plt.plot(history["train_loss"], label="Train Loss")
    plt.plot(history["val_loss"], label="Val Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Loss (CrossEntropy)")
    plt.legend()

    # Acc
    plt.subplot(1,2,2)
    plt.plot(history["train_acc"], label="Train Acc")
    plt.plot(history["val_acc"], label="Val Acc")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy (%)")
    plt.title("ID Classification Accuracy")
    plt.legend()

    plot_path = "artifacts/plots/reid_training_curves.png"
    plt.tight_layout()
    plt.savefig(plot_path)
    print(f"📊 Saved training plot to {plot_path}")
    plt.show()

if __name__ == "__main__":
    train_reid()
