import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))


import torch
from elephant_vision.reid_model_v2 import ElephantReIDv2

model = ElephantReIDv2().cuda().eval()
x = torch.randn(4, 3, 256, 256).cuda()
with torch.amp.autocast("cuda"):
    y = model(x)
print("Output shape:", y.shape)
