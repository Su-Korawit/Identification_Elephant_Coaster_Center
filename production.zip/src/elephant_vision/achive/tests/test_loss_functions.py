import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))


import torch
from elephant_vision.train_reid_v2_fixed import ArcFace, BatchHardTripletLoss

emb = torch.randn(8, 256).cuda()
labels = torch.randint(0, 2, (8,)).cuda()

arc = ArcFace(256, 2).cuda()
triplet = BatchHardTripletLoss().cuda()

logits = arc(emb, labels)
loss1 = torch.nn.functional.cross_entropy(logits, labels)
loss2 = triplet(emb, labels)
print("ArcFace Loss:", loss1.item(), "Triplet Loss:", loss2.item())
