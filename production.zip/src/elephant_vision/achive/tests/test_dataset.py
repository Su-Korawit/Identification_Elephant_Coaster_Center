import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))

from elephant_vision.train_reid_v2_fixed import ReidFolder
from elephant_vision.transforms import get_train_transform
from pathlib import Path

dataset = ReidFolder(Path("artifacts/datasets/reid/train"), get_train_transform())
print("Total samples:", len(dataset))
img, label = dataset[0]
print("Image shape:", img.shape, "Label:", label)
