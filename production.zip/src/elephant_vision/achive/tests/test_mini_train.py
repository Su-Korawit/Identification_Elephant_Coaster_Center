# import sys, os
# sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))

import torch
from elephant_vision.train_reid_v2_fixed import ReidFolder, PKSampler, ArcFace, BatchHardTripletLoss
from elephant_vision.reid_model_v2 import ElephantReIDv2
from elephant_vision.transforms import get_train_transform
from torch.utils.data import DataLoader
from tqdm import tqdm

ds = ReidFolder("artifacts/datasets/reid/train", get_train_transform())
loader = DataLoader(ds, batch_size=8, sampler=PKSampler(ds, 2, 4), num_workers=0)

model = ElephantReIDv2(256).cuda()
arc = ArcFace(256, len(ds.id2name)).cuda()
triplet = BatchHardTripletLoss().cuda()
opt = torch.optim.AdamW(model.parameters(), lr=3e-4)

for imgs, labels in tqdm(loader, total=5):
    imgs, labels = imgs.cuda(), labels.cuda()
    with torch.amp.autocast("cuda"):
        emb = model(imgs)
        logits = arc(emb, labels)
        loss = torch.nn.functional.cross_entropy(logits, labels) + triplet(emb, labels)
    opt.zero_grad()
    loss.backward()
    opt.step()
    print("Loss:", loss.item())
    break