# src/elephant_vision/tests/test_reid_v2_infer.py
import os, sys
# ✅ เพิ่ม path ของโฟลเดอร์ src เข้าไปใน sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_DIR = os.path.join(BASE_DIR, "..")   # ไปถึงระดับ src
sys.path.append(ROOT_DIR)

import torch, time
from elephant_vision.reid_model_v2 import ElephantReIDv2

device = "cuda" if torch.cuda.is_available() else "cpu"
model = ElephantReIDv2().to(device).eval()

x = torch.randn(8, 3, 256, 256).to(device)

# warm-up
for _ in range(5):
    _ = model(x)

# timing
torch.cuda.synchronize()
start = time.time()
_ = model(x)
torch.cuda.synchronize()
end = time.time()

print(f"✅ Model output shape: {_.shape}")
print(f"⚡ Inference time: {(end-start):.4f} sec per batch")
print(f"Device: {device}, Mixed precision: {torch.cuda.is_available()}")

