import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

LOG_PATH = Path("logs/train_v2.csv")
OUT_PATH = Path("artifacts/outputs/train_report.png")

df = pd.read_csv(LOG_PATH)
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.plot(df["epoch"], df["total_loss"], label="Total Loss", color="royalblue")
plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Training Loss Curve"); plt.legend()

plt.subplot(1, 2, 2)
plt.plot(df["epoch"], df["loss_arc"], label="ArcFace", color="tomato", alpha=0.7)
plt.plot(df["epoch"], df["loss_triplet"], label="Triplet", color="orange", alpha=0.7)
plt.xlabel("Epoch"); plt.ylabel("Component Loss"); plt.title("ArcFace & Triplet Loss"); plt.legend()

plt.tight_layout(); OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
plt.savefig(OUT_PATH, dpi=200)
print(f"✅ Saved report: {OUT_PATH}")
plt.show()
