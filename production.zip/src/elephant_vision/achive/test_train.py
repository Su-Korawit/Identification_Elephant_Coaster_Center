# src/elephant_vision/test_train.py
import torch
from elephant_vision.reid_model import ElephantReIDModel
from elephant_vision.reid_dataset import get_reid_dataloader
import torch.nn.functional as F

if __name__ == "__main__":
    model = ElephantReIDModel(num_classes=None)
    model.load_state_dict(torch.load("artifacts/models/reid_model.pt", map_location="cpu"))
    model.eval()

    dataloader, dataset = get_reid_dataloader("artifacts/datasets/reid/train", batch_size=8)
    names = dataset.classes

    with torch.no_grad():
        imgs, labels = next(iter(dataloader))
        embeds = model(imgs)
        sim = F.cosine_similarity(embeds[0].unsqueeze(0), embeds)
        print(f"Similarity to first image: {sim.tolist()}")
