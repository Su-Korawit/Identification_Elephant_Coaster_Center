# src/elephant_vision/test_search.py
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import cv2
import torch
import faiss
import numpy as np
from elephant_vision.reid_model import ElephantReIDModel
from torchvision import transforms
from elephant_vision.enhance import enhance_image
from elephant_vision.transforms import get_infer_transform

def identify_elephant(image_path, model_path, index_path, names_path, top_k=3):
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # โหลดโมเดล
    model = ElephantReIDModel(num_classes=None).to(device)
    state_dict = torch.load(model_path, map_location=device)
    missing, unexpected = model.load_state_dict(state_dict, strict=False)
    if unexpected:
        print(f"⚠️ Skipped keys: {unexpected}")
    model.eval()

    # โหลด FAISS index
    index = faiss.read_index(index_path)
    names = np.load(names_path, allow_pickle=True)

    # เตรียมภาพ
    from PIL import Image

    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"❌ Cannot read image at {image_path}")
    #img = enhance_image(img)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)

    transform = get_infer_transform()

    tensor = transform(img).unsqueeze(0).to(device)

    # สร้าง embedding
    with torch.no_grad():
        embed = model(tensor).cpu().numpy().astype("float32")

    # ค้นหาใน FAISS index
    D, I = index.search(embed, top_k)
    results = [(names[i], float(D[0][j])) for j, i in enumerate(I[0])]

    # 🔹 ตั้ง threshold สำหรับ Unknown
    threshold = 0.60  # ปรับตาม dataset ของคุณ

    best_name, best_dist = results[0]
    if best_dist > threshold:
        print(f"🟠 Unknown Elephant (closest match: {best_name}, distance={best_dist:.4f})")
    else:
        print(f"✅ Identified as: {best_name} (distance={best_dist:.4f})")

    # แสดง top-k ทั้งหมด
    print("\n🔍 Top-k results:")
    for name, dist in results:
        print(f"  {name} (distance {dist:.4f})")

    print("🔍 Search results:")
    for name, dist in results:
        print(f"  {name} (distance {dist:.4f})")

if __name__ == "__main__":
    identify_elephant(
        image_path=r"D:\Identification_Elephant_Coaster_Center\SampleDataset\test_unknown.jpg",
        model_path="artifacts/models/reid_model.pt",
        index_path="artifacts/indexes/elephants.index",
        names_path="artifacts/indexes/elephant_names.npy"
    )
