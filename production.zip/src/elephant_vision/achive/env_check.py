# src/elephant_vision/env_check.py
import os
import importlib.util
import torch
import platform

def check_package(pkg_name: str) -> bool:
    """ตรวจว่า package ติดตั้งอยู่หรือไม่"""
    spec = importlib.util.find_spec(pkg_name)
    return spec is not None

def test_environment():
    print("🐘 Elephant Identification - Environment Check\n")

    # ตรวจ Python
    py_ver = platform.python_version()
    print(f"Python version : {py_ver}")

    # ตรวจ Torch และ GPU
    if check_package("torch"):
        print("Torch           : ✅ Installed")
        print(f"CUDA available  : {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            device = torch.cuda.get_device_name(0)
            cc = torch.cuda.get_device_capability(0)
            print(f"CUDA device     : {device} (capability {cc})")
        else:
            print("⚠️  CUDA not detected, running on CPU mode.")
    else:
        print("❌ Torch not installed")

    # ตรวจ OpenCV และ YOLO
    print(f"OpenCV installed : {check_package('cv2')}")
    print(f"Ultralytics (YOLO) installed : {check_package('ultralytics')}")

    # ตรวจโฟลเดอร์ artifacts
    base_dirs = ["artifacts/datasets", "artifacts/models",
                 "artifacts/indexes", "artifacts/outputs"]
    for d in base_dirs:
        os.makedirs(d, exist_ok=True)
        testfile = os.path.join(d, "test.tmp")
        try:
            with open(testfile, "w") as f:
                f.write("ok")
            os.remove(testfile)
            print(f"✅ Directory ready: {d}")
        except Exception as e:
            print(f"❌ Cannot write to {d}: {e}")

    print("\n✅ Environment check complete.\n")

if __name__ == "__main__":
    test_environment()

