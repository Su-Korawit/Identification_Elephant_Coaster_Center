# src/elephant_vision/reid_model_v2.py
import torch
import torch.nn as nn
from torchvision.models import convnext_small

class ElephantReIDv2(nn.Module):
    """
    ConvNeXt-Small backbone + FP16 support + 256D embedding
    Compatible with FAISS index from v1 (can reindex if needed)
    """
    def __init__(self, embedding_dim=256):
        super().__init__()
        base = convnext_small(weights="IMAGENET1K_V1")

        # ใช้ feature extractor
        self.backbone = base.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(768, embedding_dim)  # ConvNeXt-Small output dim = 768
        self.bn = nn.BatchNorm1d(embedding_dim)

    def forward(self, x):
        # เปิด mixed precision เพื่อให้เร็วขึ้น
        with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
            feat = self.backbone(x)
            feat = self.pool(feat).flatten(1)
            feat = self.fc(feat)
            feat = self.bn(feat)
            feat = nn.functional.normalize(feat, dim=1)
        return feat

