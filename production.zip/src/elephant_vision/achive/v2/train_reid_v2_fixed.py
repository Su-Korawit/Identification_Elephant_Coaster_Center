# src/elephant_vision/train_reid_v2_fixed.py
import os, sys, csv, time, random, glob
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, Sampler
from torchvision import transforms
from tqdm import tqdm
from PIL import Image

# --------- make src importable ---------
BASE_DIR = Path(__file__).resolve().parents[2]
SRC_DIR = BASE_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.append(str(SRC_DIR))

from elephant_vision.reid_model_v2 import ElephantReIDv2
from elephant_vision.transforms import get_train_transform

# --------- Config ---------
TRAIN_DIR = BASE_DIR / "artifacts" / "datasets" / "reid" / "train"
OUT_DIR   = BASE_DIR / "artifacts" / "models"
LOG_DIR   = BASE_DIR / "logs"
OUT_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

EPOCHS = 10
BATCH_P, BATCH_K = 4, 4
BATCH_SIZE = BATCH_P * BATCH_K
LR, WD = 3e-4, 1e-4
NUM_WORKERS = 4  # ลด worker เพื่อไม่ให้ค้าง
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
AMP = torch.cuda.is_available()
random.seed(42); np.random.seed(42); torch.manual_seed(42)

# ===============================================================
# Dataset
# ===============================================================
class ReidFolder(Dataset):
    def __init__(self, root, transform):
        self.root = Path(root)
        self.transform = transform
        self.samples, self.labels, self.id2name = [], [], []
        for cid, name in enumerate(sorted([d.name for d in self.root.iterdir() if d.is_dir()])):
            paths = sorted(sum([glob.glob(str(self.root/name/f"*.{ext}")) for ext in ["jpg","png","jpeg"]], []))
            if len(paths) == 0: continue
            self.id2name.append(name)
            for p in paths:
                self.samples.append(p)
                self.labels.append(cid)
        self.labels = np.array(self.labels, dtype=np.int64)
        self.by_id = {}
        for i, y in enumerate(self.labels):
            self.by_id.setdefault(int(y), []).append(i)

    def __len__(self): return len(self.samples)

    def __getitem__(self, idx):
        path = self.samples[idx]
        img = Image.open(path).convert("RGB")
        img = self.transform(img)
        label = int(self.labels[idx])
        return img, label

# ===============================================================
# Sampler (P×K)
# ===============================================================
class PKSampler(torch.utils.data.Sampler):
    def __init__(self, dataset: ReidFolder, P: int, K: int):
        self.ds = dataset; self.P = P; self.K = K
        self.ids = list(dataset.by_id.keys())

    def __iter__(self):
        ids = self.ids.copy()
        random.shuffle(ids)
        while True:
            if len(ids) < self.P:
                ids = self.ids.copy()
                random.shuffle(ids)
            pick = ids[:self.P]
            ids = ids[self.P:]
            batch = []
            for pid in pick:
                imgs = self.ds.by_id[pid]
                if len(imgs) >= self.K:
                    chosen = random.sample(imgs, self.K)
                else:
                    chosen = np.random.choice(imgs, self.K, replace=True).tolist()
                batch.extend(chosen)
            yield from batch

# ===============================================================
# Loss Functions
# ===============================================================
class ArcFace(nn.Module):
    def __init__(self, in_features, n_classes, s=30.0, m=0.4):
        super().__init__()
        self.s, self.m = s, m
        self.W = nn.Parameter(torch.randn(n_classes, in_features))
        nn.init.xavier_uniform_(self.W)

    def forward(self, x, labels):
        x = F.normalize(x, dim=1)
        W = F.normalize(self.W, dim=1)
        logits = torch.matmul(x, W.t())
        theta = torch.acos(torch.clamp(logits, -1+1e-7, 1-1e-7))
        target_logits = torch.cos(theta + self.m)
        onehot = F.one_hot(labels, num_classes=W.size(0)).float()
        logits = logits * (1 - onehot) + target_logits * onehot
        return logits * self.s

class BatchHardTripletLoss(nn.Module):
    def __init__(self, margin=0.3): super().__init__(); self.margin = margin
    def forward(self, embeddings, labels):
        dist = torch.cdist(embeddings, embeddings, p=2)
        labels = labels.unsqueeze(1)
        pos_mask = (labels == labels.t()).bool()
        neg_mask = (labels != labels.t()).bool()
        pos_dist = (dist + (~pos_mask) * (-1e9)).max(1)[0]
        neg_dist = (dist + (~neg_mask) * (1e9)).min(1)[0]
        return F.relu(pos_dist - neg_dist + self.margin).mean()

# ===============================================================
# Train
# ===============================================================
def main():
    print(f"[INFO] Using device: {DEVICE} ({torch.cuda.get_device_name(0) if DEVICE=='cuda' else 'CPU'})")
    print(f"🐘 Phase 2 Training on: {TRAIN_DIR}")
    train_tf = get_train_transform()
    train_set = ReidFolder(root=TRAIN_DIR, transform=train_tf)
    print(f"IDs: {train_set.id2name}")

    train_loader = DataLoader(
        train_set,
        batch_size=BATCH_SIZE,
        sampler=PKSampler(train_set, P=BATCH_P, K=BATCH_K),
        num_workers=NUM_WORKERS,
        pin_memory=True
    )

    model = ElephantReIDv2(embedding_dim=256).to(DEVICE)
    criterion_arc = ArcFace(256, len(train_set.id2name)).to(DEVICE)
    criterion_triplet = BatchHardTripletLoss().to(DEVICE)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WD)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)
    scaler = torch.amp.GradScaler("cuda", enabled=AMP)

    log_path = LOG_DIR / "train_v2.csv"
    with open(log_path, "w", newline="") as f:
        csv.writer(f).writerow(["epoch", "loss_arc", "loss_triplet", "total_loss", "time(s)"])

    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = total_arc = total_trip = 0.0
        t0 = time.time()

        for imgs, labels in tqdm(train_loader, desc=f"Epoch {epoch}/{EPOCHS}"):
            imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            with torch.amp.autocast("cuda", enabled=AMP):
                emb = model(imgs)
                logits = criterion_arc(emb, labels)
                loss_arc = F.cross_entropy(logits, labels)
                loss_trip = criterion_triplet(emb, labels)
                loss = loss_arc + 0.3 * loss_trip
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            total_loss += loss.item(); total_arc += loss_arc.item(); total_trip += loss_trip.item()

        scheduler.step()
        avg_loss, avg_arc, avg_trip = total_loss/len(train_loader), total_arc/len(train_loader), total_trip/len(train_loader)
        dur = time.time()-t0
        print(f"[Epoch {epoch}/{EPOCHS}] total={avg_loss:.4f} arc={avg_arc:.4f} trip={avg_trip:.4f} ({dur:.1f}s)")
        with open(log_path, "a", newline="") as f:
            csv.writer(f).writerow([epoch, avg_arc, avg_trip, avg_loss, f"{dur:.1f}"])
        torch.save(model.state_dict(), OUT_DIR / f"reid_model_v2_epoch{epoch}.pt")

    torch.save(model.state_dict(), OUT_DIR / "reid_model_v2.pt")
    print(f"✅ Model saved to {OUT_DIR / 'reid_model_v2.pt'}")
    print("🎉 Training finished!")

if __name__ == "__main__":
    main()
