# src/elephant_vision/test_crop.py
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from elephant_vision.yolo_crop import process_input

# if __name__ == "__main__":
#     input_path = r"D:\Identification_Elephant_Coaster_Center\Day1_workshop_data_E"
#     print(f"Processing {input_path}")
#     process_input(input_path, elephant_name=None, frame_stride=5)
#     print("✅ Test finished.")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        input_path = sys.argv[1]
    else:
        input_path = r"D:\Identification_Elephant_Coaster_Center\Day1_workshop_data_E"

    print(f"Processing {input_path}")
    process_input(input_path, elephant_name=None, frame_stride=5)
    print("✅ Test finished.")