# src/elephant_vision/reid_model.py
import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F

class ElephantReIDModel(nn.Module):
    def __init__(self, embedding_dim=512, num_classes=None, dropout_p=0.5):
        super().__init__()

        # 🧠 เปลี่ยน backbone จาก ResNet-50 → ResNet-18
        # เหตุผล: ResNet-18 พารามิเตอร์น้อยกว่า ~2.3x → overfit ยากขึ้น
        backbone = models.resnet18(weights="IMAGENET1K_V1")

        # ตัดเอาส่วน feature extractor (จนถึง global avgpool)
        self.feature_extractor = nn.Sequential(*list(backbone.children())[:-1])
        in_features = backbone.fc.in_features  # 512 สำหรับ resnet18

        # ฝั่ง projection ไปเป็น embedding (face-style / ReID-style)
        self.embedding_layer = nn.Sequential(
            nn.Linear(in_features, embedding_dim),
            nn.BatchNorm1d(embedding_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout_p),
        )

        # classifier สำหรับ softmax training
        self.classifier = None
        if num_classes is not None:
            self.classifier = nn.Linear(embedding_dim, num_classes)

    def forward(self, x):
        # CNN backbone
        x = self.feature_extractor(x)   # (B, C, 1, 1)
        x = x.flatten(1)                # (B, C)

        # projection + regularization
        x = self.embedding_layer(x)     # (B, embedding_dim)

        # L2 normalize เพื่อใช้เป็น vector สำหรับ FAISS
        emb = F.normalize(x, p=2, dim=1)

        if self.classifier is not None:
            logits = self.classifier(emb)
            return emb, logits

        return emb
