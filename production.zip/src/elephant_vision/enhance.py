# src/elephant_vision/enhance.py
import cv2
import numpy as np

def is_blurry(image, threshold=100.0):
    """ตรวจว่าภาพเบลอเกินไปหรือไม่ (ค่ามากคือคมชัด)"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    fm = cv2.Laplacian(gray, cv2.CV_64F).var()
    return fm < threshold

def enhance_image(image):
    """ปรับคุณภาพภาพให้นำไปเทรนได้ดีขึ้น"""
    # เพิ่ม contrast ด้วย CLAHE
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
    cl = clahe.apply(l)
    lab = cv2.merge((cl, a, b))
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    # sharpen
    kernel = np.array([[0, -1, 0],
                       [-1, 5,-1],
                       [0, -1, 0]])
    sharpened = cv2.filter2D(enhanced, -1, kernel)

    # resize เพื่อให้ขนาดคงที่
    sharpened = cv2.resize(sharpened, (256, 256))
    return sharpened

