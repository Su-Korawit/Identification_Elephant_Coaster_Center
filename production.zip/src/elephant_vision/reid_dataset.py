# src/elephant_vision/reid_dataset.py
import os
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split

def get_reid_dataloaders(
    data_dir="artifacts/datasets/reid/train",
    batch_size=16,
    num_workers=2,
    val_ratio=0.2,
):
    """
    โหลด dataset รูปช้าง แล้วแตกเป็น train / val
    โดยยังใช้ ImageFolder โฟลเดอร์ละ 1 ตัวช้าง
    """

    # 🔁 Augmentation หนักขึ้นเพื่อกัน overfitting:
    # - RandomResizedCrop : จำลองระยะกล้องต่างกัน
    # - RandomHorizontalFlip : ซ้าย/ขวา
    # - ColorJitter : กลางวัน/เย็น/ส้ม/มืด
    # - RandomRotation / Perspective : มุมเอียง, หัวก้มเงย
    # - GaussianBlur : ถ่ายไกล / motion blur
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop((256, 128), scale=(0.8, 1.0), ratio=(0.6, 1.0)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
        transforms.RandomRotation(degrees=15),
        transforms.RandomPerspective(distortion_scale=0.3, p=0.5),
        transforms.GaussianBlur(kernel_size=3),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        ),
    ])

    # 🧪 validation transform เบากว่า: ไม่ต้องสุ่มเยอะ
    val_transform = transforms.Compose([
        transforms.Resize((256, 128)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        ),
    ])

    full_dataset = datasets.ImageFolder(data_dir)

    # สร้าง train/val split แบบ stratified คร่าว ๆ ด้วย random_split ตามสัดส่วน
    val_count = int(len(full_dataset) * val_ratio)
    train_count = len(full_dataset) - val_count
    train_subset, val_subset = random_split(full_dataset, [train_count, val_count])

    # ใส่ transform ให้ subset ต่างกัน
    train_subset.dataset.transform = train_transform
    val_subset.dataset.transform = val_transform

    train_loader = DataLoader(
        train_subset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
    )

    val_loader = DataLoader(
        val_subset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    return train_loader, val_loader, full_dataset
