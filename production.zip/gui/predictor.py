from PyQt6.QtCore import QThread, pyqtSignal
import subprocess, sys, os, datetime

class PredictorWorker(QThread):
    log_message = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, base_dir, test_path, parent=None):
        super().__init__(parent)
        self.base_dir = base_dir
        self.test_path = test_path

    def run(self):
        def log(msg): self.log_message.emit(f"[{datetime.datetime.now():%H:%M:%S}] {msg}")

        cmd = [sys.executable, os.path.join(self.base_dir, "infer.py"), self.test_path]
        log(f"▶ Running infer.py {self.test_path}")
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True,
                                   encoding="utf-8", errors="replace")
        for line in iter(process.stdout.readline, ''):
            if line.strip(): self.log_message.emit(f"[infer] {line.strip()}")
        process.wait()
        log("✅ Inference done")
        self.finished.emit()
