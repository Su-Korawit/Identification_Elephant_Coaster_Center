from PyQt6.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

class LossPlotWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.figure = Figure(figsize=(4,3))
        self.canvas = FigureCanvasQTAgg(self.figure)
        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        self.setLayout(layout)
        self.ax = self.figure.add_subplot(111)
        self.losses = []
        self.ax.set_title("Training Loss")
        self.ax.set_xlabel("Step")
        self.ax.set_ylabel("Loss")

    def add_point(self, epoch, it, loss):
        self.losses.append(loss)
        self.ax.cla()
        self.ax.plot(self.losses, color='lime')
        self.ax.set_title("Training Loss")
        self.ax.set_xlabel("Step")
        self.ax.set_ylabel("Loss")
        self.canvas.draw()
