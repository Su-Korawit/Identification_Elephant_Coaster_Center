from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QPushButton, QLabel, QTextEdit,
    QVBoxLayout, QHBoxLayout, QFileDialog, QProgressBar, QMessageBox
)
from trainer import TrainerWorker
from predictor import PredictorWorker
from plot_widget import LossPlotWidget
import os

BASE_DIR = r"D:\Identification_Elephant_Coaster_Center\src\elephant_vision"

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🐘 Elephant Identification GUI (One-Click)")
        self.resize(1200, 800)
        self._init_ui()
        self.input_path = None
        self.test_path = None
        self.trainerWorker = None
        self.predictorWorker = None

    def _init_ui(self):
        self.selectBtn = QPushButton("📁 Select Training Folder")
        self.trainBtn = QPushButton("▶ Start Training")
        self.testBtn = QPushButton("🧪 Select Test Folder")
        self.predictBtn = QPushButton("🔍 Run Prediction")
        self.consoleOutput = QTextEdit()
        self.consoleOutput.setReadOnly(True)
        self.progressBar = QProgressBar()
        self.lossPlot = LossPlotWidget()

        left = QVBoxLayout()
        for w in [self.selectBtn, self.trainBtn, self.testBtn, self.predictBtn,
                  QLabel("Logs:"), self.consoleOutput, self.progressBar]:
            left.addWidget(w)

        right = QVBoxLayout()
        right.addWidget(QLabel("Training Progress"))
        right.addWidget(self.lossPlot)

        main = QHBoxLayout()
        main.addLayout(left, 1)
        main.addLayout(right, 2)
        container = QWidget()
        container.setLayout(main)
        self.setCentralWidget(container)

        self.selectBtn.clicked.connect(self._choose_input_path)
        self.trainBtn.clicked.connect(self._start_training)
        self.testBtn.clicked.connect(self._choose_test_path)
        self.predictBtn.clicked.connect(self._run_prediction)

    def _choose_input_path(self):
        path = QFileDialog.getExistingDirectory(self, "Select Dataset Folder")
        if path:
            self.input_path = path
            self.consoleOutput.append(f"Selected training input: {path}")

    def _start_training(self):
        if not self.input_path:
            QMessageBox.warning(self, "Warning", "Please select dataset first.")
            return
        self.trainerWorker = TrainerWorker(BASE_DIR, self.input_path)
        self.trainerWorker.log_message.connect(self.consoleOutput.append)
        self.trainerWorker.progress_update.connect(self.progressBar.setValue)
        self.trainerWorker.finished.connect(lambda _: self.consoleOutput.append("✅ Training complete"))
        self.trainerWorker.start()

    def _choose_test_path(self):
        path = QFileDialog.getExistingDirectory(self, "Select Test Folder")
        if path:
            self.test_path = path
            self.consoleOutput.append(f"Selected test folder: {path}")

    def _run_prediction(self):
        if not self.test_path:
            QMessageBox.warning(self, "Warning", "Please select test folder.")
            return
        self.predictorWorker = PredictorWorker(BASE_DIR, self.test_path)
        self.predictorWorker.log_message.connect(self.consoleOutput.append)
        self.predictorWorker.finished.connect(lambda: self.consoleOutput.append("✅ Prediction finished"))
        self.predictorWorker.start()
