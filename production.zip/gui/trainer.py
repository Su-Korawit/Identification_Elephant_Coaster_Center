from PyQt6.QtCore import QThread, pyqtSignal
import subprocess, sys, os, datetime

class TrainerWorker(QThread):
    log_message = pyqtSignal(str)
    progress_update = pyqtSignal(int)
    finished = pyqtSignal(str)

    def __init__(self, base_dir, dataset_path, parent=None):
        super().__init__(parent)
        self.base_dir = base_dir
        self.dataset_path = dataset_path

    def run(self):
        def log(msg): self.log_message.emit(f"[{datetime.datetime.now():%H:%M:%S}] {msg}")

        def run_script(script, args=[]):
            cmd = [sys.executable, os.path.join(self.base_dir, script)] + args
            log(f"▶ Running {script} {' '.join(args)}")
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True,
                                       encoding="utf-8", errors="replace")
            for line in iter(process.stdout.readline, ''):
                if line.strip(): self.log_message.emit(f"[{script}] {line.strip()}")
            process.wait()
            log(f"✅ {script} finished")

        try:
            run_script("test_crop.py", [self.dataset_path])
            self.progress_update.emit(25)
            run_script("train_reid.py")
            self.progress_update.emit(75)
            run_script("build_faiss.py")
            self.progress_update.emit(100)
            self.finished.emit("artifacts/models/reid_model.pt")
        except Exception as e:
            log(f"❌ Training pipeline failed: {e}")
