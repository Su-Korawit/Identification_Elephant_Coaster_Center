# ===============================================================
# 📁 FILE: src/elephant_vision/build_faiss.py
# ---------------------------------------------------------------
# หน้าที่ของสคริปต์นี้: 
#   สร้างฐานข้อมูล "FAISS Index" สำหรับใช้ค้นหาช้างจาก embedding vector
#   (หลังเทรนโมเดลเสร็จแล้ว)
#
# Pipeline:
#   1. โหลดโมเดล ElephantReIDModel
#   2. ดึง embedding ของภาพช้างทุกภาพใน dataset
#   3. สร้าง FAISS index เพื่อค้นหาความใกล้เคียงแบบเร็ว
#   4. บันทึก index และชื่อช้างแต่ละ embedding
# ===============================================================

import sys, os
from xml.parsers.expat import model  # ❗ (ไม่จำเป็นจริง ๆ — แต่อาจหลงเหลือจาก debug)
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# ↑ เพิ่ม path ของ src เพื่อ import โมดูลภายใน (เช่น reid_model, reid_dataset)

import torch
import faiss           # ไลบรารีค้นหาความคล้ายของ vector ขนาดใหญ่ (Facebook AI Similarity Search)
import numpy as np
from elephant_vision.reid_model import ElephantReIDModel
from elephant_vision.reid_dataset import get_reid_dataloaders
from tqdm import tqdm  # ใช้แสดง progress bar ขณะประมวลผล

# ---------------------------------------------------------------
# 🧩 ฟังก์ชันหลัก: build_faiss_index
# ---------------------------------------------------------------
def build_faiss_index(
    model_path="artifacts/models/reid_model.pt",       # path โมเดล ReID ที่เทรนไว้
    data_dir="artifacts/datasets/reid/train",          # dataset ชุดที่มีภาพของช้างแต่ละตัว
    index_path="artifacts/indexes/elephants.index",    # path สำหรับบันทึก FAISS index
    names_path="artifacts/indexes/elephant_names.npy", # path สำหรับบันทึกชื่อช้าง
    use_gpu=True                                       # ใช้ GPU acceleration ถ้ามี
):
    # -----------------------------------------------------------
    # ⚙️ เลือกอุปกรณ์ประมวลผล (GPU ถ้ามี)
    # -----------------------------------------------------------
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # -----------------------------------------------------------
    # 🧠 โหลดโมเดล ReID ที่เทรนไว้
    # -----------------------------------------------------------
    model = ElephantReIDModel(num_classes=None).to(device)
    # num_classes=None → โหลดเฉพาะส่วน embedding ไม่ใช้ classifier
    state_dict = torch.load(model_path, map_location=device)

    # strict=False → อนุญาตให้โหลดเฉพาะ weights ที่ตรงกับโครงสร้าง
    missing, unexpected = model.load_state_dict(state_dict, strict=False)
    if unexpected:
        print(f"⚠️ Skipped keys: {unexpected}")  # แจ้งเตือนถ้ามี layer ที่ไม่ตรง (มักเกิดจากตัด classifier ออก)
    model.eval()  # ปิด dropout/batchnorm update

    # -----------------------------------------------------------
    # 📦 โหลด dataset สำหรับสร้าง embedding
    # -----------------------------------------------------------
    # เราไม่ต้องการ split train/val ที่นี่ — ต้องการ embeddings ทั้งหมด
    train_loader, _, dataset = get_reid_dataloaders(
        data_dir,
        batch_size=16,
        val_ratio=0.0  # ใช้ข้อมูลทั้งหมดเป็น train
    )

    # รายชื่อ class (ชื่อช้าง)
    names = dataset.classes

    embeddings, labels = [], []  # เก็บเวกเตอร์และ label ของแต่ละภาพ

    print(f"📦 Generating embeddings for {len(dataset)} images...")

    # -----------------------------------------------------------
    # 🔄 ผ่านภาพทั้งหมด → สร้าง embedding ด้วยโมเดล ReID
    # -----------------------------------------------------------
    with torch.no_grad():  # ปิด gradient เพื่อให้ inference เร็วขึ้น
        for imgs, lbls in tqdm(train_loader):  # tqdm → แสดง progress bar
            imgs = imgs.to(device)
            embed = model(imgs)  # Forward ผ่านโมเดลเพื่อสร้าง embedding
            embeddings.append(embed.cpu().numpy())  # ย้ายกลับ CPU แล้วแปลงเป็น numpy
            labels.extend(lbls.numpy())  # เก็บ label (ตัวเลข index ของ class)

    # รวม embeddings ทั้งหมดเป็น array เดียว (N, D)
    embeddings = np.vstack(embeddings).astype("float32")
    dim = embeddings.shape[1]
    print(f"🧠 Embedding shape: {embeddings.shape}")

    # -----------------------------------------------------------
    # 🔍 สร้าง FAISS Index สำหรับค้นหาเวกเตอร์
    # -----------------------------------------------------------
    # IndexHNSWFlat → เป็นกราฟแบบ HNSW (Hierarchical Navigable Small World)
    # มีความเร็วใกล้เคียง ANN (Approximate Nearest Neighbor)
    # เหมาะสำหรับใช้ค้นหาใน embedding หลายพัน - หลายล้านรายการ
    #
    # dim = มิติของเวกเตอร์ (512 โดยทั่วไป)
    # m = จำนวน neighbors ที่เชื่อมต่อในกราฟ (ค่าเริ่มต้น 32)
    m = 32
    index = faiss.IndexHNSWFlat(dim, m)
    index.hnsw.efConstruction = 64  # จำนวนเพื่อนที่ใช้ตอนสร้างกราฟ
    index.hnsw.efSearch = 32        # จำนวนเพื่อนที่ค้นหา (ยิ่งมาก → แม่นขึ้นแต่ช้าลง)

    # -----------------------------------------------------------
    # ⚡ ย้ายไป GPU (ถ้ามี)
    # -----------------------------------------------------------
    # FAISS มี implementation บน GPU ด้วย (เร่งความเร็วมาก)
    if use_gpu and torch.cuda.is_available() and hasattr(faiss, "StandardGpuResources"):
        res = faiss.StandardGpuResources()
        index = faiss.index_cpu_to_gpu(res, 0, index)
        print("⚡ Using FAISS GPU acceleration")

    # -----------------------------------------------------------
    # ➕ เพิ่ม embeddings ทั้งหมดลง index
    # -----------------------------------------------------------
    index.add(embeddings)
    # ตอนนี้ index สามารถใช้ค้นหา nearest neighbor ได้แล้ว เช่น
    #   D, I = index.search(query_vector, k=5)
    #   → I คือ index ของช้างที่ใกล้เคียงที่สุด 5 ตัว

    # -----------------------------------------------------------
    # 💾 เซฟ index และรายชื่อช้าง
    # -----------------------------------------------------------
    # FAISS ต้องอยู่บน CPU ก่อนบันทึก
    if hasattr(faiss, "GpuIndex") and isinstance(index, faiss.GpuIndex):
        index = faiss.index_gpu_to_cpu(index)
    else:
        print("⚠️ FAISS GPU not detected — using CPU index instead.")

    # สร้างโฟลเดอร์ artifacts/indexes ถ้ายังไม่มี
    os.makedirs(os.path.dirname(index_path), exist_ok=True)

    # บันทึกตัว index (เวกเตอร์ทั้งหมด)
    faiss.write_index(index, index_path)

    # บันทึกชื่อช้างแต่ละ embedding เป็น numpy array
    np.save(names_path, np.array([names[i] for i in labels]))

    print(f"✅ Index saved: {index_path}")
    print(f"✅ Names saved: {names_path}")
    print(f"📈 Total vectors: {index.ntotal}, dimension: {dim}")

# ---------------------------------------------------------------
# 🚀 ENTRY POINT
# ---------------------------------------------------------------
if __name__ == "__main__":
    build_faiss_index()


# ===============================================================
# 🧭 FINAL SUMMARY (สรุปภาพรวมของสคริปต์)
# ===============================================================
# 🎯 จุดประสงค์:
#   สร้าง FAISS Index จาก embeddings ของช้างทั้งหมดใน dataset
#   เพื่อให้ระบบสามารถ “ค้นหาช้างตัวที่คล้ายที่สุด” ได้ภายหลัง
#
# ⚙️ ขั้นตอนการทำงาน:
#   1. โหลดโมเดล ElephantReIDModel ที่เทรนเสร็จแล้ว
#   2. ใช้โมเดลสร้าง embedding vector จากภาพช้างทุกภาพ
#   3. สร้าง FAISS Index (HNSWFlat) เพื่อจัดเก็บและค้นหาด้วยความเร็วสูง
#   4. เซฟทั้ง index และชื่อช้างแต่ละ embedding ลง disk
#
# 💡 แนวคิดเบื้องหลัง:
#   - FAISS ทำงานคล้าย “Google Search” สำหรับเวกเตอร์
#   - เราไม่ต้องเทียบทุกภาพทีละตัว → แค่ query แล้วหาผลลัพธ์ใกล้เคียงที่สุด
#
# 🔍 เปรียบเทียบเชิงภาพ:
#   - reid_model.py  = สมองที่จำลักษณะช้างได้
#   - build_faiss.py = สมองส่วนเก็บความจำและค้นหาความคล้าย
#
# 🧠 ตัวอย่างการใช้งานภายหลัง:
#   query_emb = model(query_image)
#   D, I = faiss_index.search(query_emb, k=3)
#   → แปลว่า "ภาพนี้ใกล้เคียงกับช้างตัวที่ I[0], I[1], I[2]"
#
# 🐘 สรุปสั้น:
#   “นี่คือสมุดรายชื่อความทรงจำของช้างทุกตัวในระบบ Elephant Vision”
# ===============================================================
