    # ===============================================================
# 📁 FILE: src/elephant_vision/reid_dataset.py
# ---------------------------------------------------------------
# หน้าที่ของสคริปต์นี้คือจัดการโหลดภาพช้างทั้งหมดจากโฟลเดอร์ dataset
# สร้าง DataLoader สำหรับ train และ validation
# พร้อม augmentation (การแปลงภาพแบบสุ่ม) เพื่อป้องกัน overfitting
# ===============================================================

import os
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split

# ---------------------------------------------------------------
# 🧩 ฟังก์ชันหลัก: get_reid_dataloaders
# ---------------------------------------------------------------
def get_reid_dataloaders(
    data_dir="artifacts/datasets/reid/train",  # path ของ dataset
    batch_size=16,                            # จำนวนภาพต่อ batch ในการเทรน
    num_workers=2,                            # จำนวน process สำหรับโหลดภาพ (ยิ่งมากยิ่งเร็ว แต่ใช้ RAM เยอะ)
    val_ratio=0.2,                            # สัดส่วน validation set (เช่น 20%)
):
    """
    โหลด dataset รูปช้าง แล้วแตกเป็น train / val
    โดยยังใช้ ImageFolder (แต่ละโฟลเดอร์ = ช้าง 1 ตัว)
    """

    # ===============================================================
    # ⚙️ TRAIN TRANSFORMS (AUGMENTATION)
    # ===============================================================
    # จุดประสงค์คือ “สร้างภาพหลากหลายแบบจากภาพเดิม” เพื่อกัน overfitting
    # โดยจำลองสถานการณ์จริง: แสงต่างกัน, มุมเอียง, ความเบลอ, ระยะกล้อง
    #
    # อธิบายแต่ละ transform:
    # - RandomResizedCrop: ครอบภาพแบบสุ่มและ resize → จำลองการถ่ายใกล้/ไกล
    # - RandomHorizontalFlip: พลิกซ้ายขวา → กัน bias จากมุมกล้อง
    # - ColorJitter: สุ่มแสง สี ความเข้ม → จำลองเวลา/สภาพแสงต่าง ๆ
    # - RandomRotation: หมุนเล็กน้อย → กันมุมก้ม/เงย/เอียง
    # - RandomPerspective: ทำให้ภาพบิดเล็กน้อย → จำลองมุมกล้องแปลก ๆ
    # - GaussianBlur: ทำภาพเบลอบางส่วน → จำลอง motion blur หรือถ่ายไกล
    # - ToTensor: แปลงจากภาพ (HWC, uint8) → เทนเซอร์ (CHW, float)
    # - Normalize: ปรับค่าสีให้อยู่ในช่วง mean/std แบบ ImageNet (มาตรฐาน)
    #
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(
            (256, 128),         # ขนาดสุดท้ายของภาพ (H, W)
            scale=(0.8, 1.0),   # สุ่มสัดส่วนครอบภาพ 80–100% ของต้นฉบับ
            ratio=(0.6, 1.0),   # ปรับอัตราส่วนกว้าง/ยาวให้หลากหลาย
        ),
        transforms.RandomHorizontalFlip(p=0.5),  # พลิกซ้าย/ขวา ครึ่งหนึ่งของภาพทั้งหมด
        transforms.ColorJitter(                   # ปรับสภาพแสงและสี
            brightness=0.4,                       # ความสว่าง ±40%
            contrast=0.4,                         # ความต่างของสี ±40%
            saturation=0.4                        # ความอิ่มสี ±40%
        ),
        transforms.RandomRotation(degrees=15),    # หมุนสุ่ม ±15 องศา
        transforms.RandomPerspective(             # บิดภาพให้เหมือนมุมกล้องเปลี่ยน
            distortion_scale=0.3, p=0.5
        ),
        transforms.GaussianBlur(kernel_size=3),   # เบลอเล็กน้อยจำลองการถ่ายไม่ชัด
        transforms.ToTensor(),                    # แปลงเป็นเทนเซอร์ PyTorch
        transforms.Normalize(                     # ปรับค่าช่องสีให้อยู่ในช่วงมาตรฐาน
            mean=[0.485, 0.456, 0.406],           # ค่ามาตรฐานจาก ImageNet
            std=[0.229, 0.224, 0.225],
        ),
    ])

    # ===============================================================
    # 🧪 VALIDATION TRANSFORM
    # ===============================================================
    # สำหรับ validation ไม่ต้องสุ่มใด ๆ เพื่อให้ผลเทียบได้ชัดเจนทุก epoch
    # ใช้แค่ resize และ normalize (ไม่หมุน ไม่บิด)
    val_transform = transforms.Compose([
        transforms.Resize((256, 128)),  # ปรับขนาดให้เท่ากันกับตอนเทรน
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        ),
    ])

    # ===============================================================
    # 📂 โหลด dataset จากโฟลเดอร์
    # ===============================================================
    # ใช้ ImageFolder ของ torchvision ซึ่งคาดหวังโครงสร้างแบบนี้:
    #
    # data_dir/
    # ├── Aiko/
    # │   ├── aiko_0001.jpg
    # │   ├── aiko_0002.jpg
    # │   └── ...
    # ├── Nongwan/
    # │   ├── nongwan_0001.jpg
    # │   └── ...
    #
    # โฟลเดอร์แต่ละชื่อ = label หนึ่งตัว (class ของช้างแต่ละตัว)
    #
    full_dataset = datasets.ImageFolder(data_dir)

    # ===============================================================
    # 🔀 แบ่ง dataset เป็น train / val
    # ===============================================================
    # เราใช้ random_split แบบสุ่มแบ่งตามสัดส่วน val_ratio
    # ยังไม่ใช่ stratified แท้ ๆ แต่เพียงพอสำหรับงานเบื้องต้น
    val_count = int(len(full_dataset) * val_ratio)   # จำนวนภาพที่ใช้ val
    train_count = len(full_dataset) - val_count      # ที่เหลือใช้ train

    # แบ่ง dataset ออกเป็น 2 ชุดย่อย
    train_subset, val_subset = random_split(full_dataset, [train_count, val_count])

    # ===============================================================
    # 🧩 ใส่ transform ให้แต่ละ subset
    # ===============================================================
    # dataset.ImageFolder มี attribute `.transform`
    # เราสามารถใส่ transform ที่ต่างกันระหว่าง train/val ได้โดยตรง
    train_subset.dataset.transform = train_transform
    val_subset.dataset.transform = val_transform

    # ===============================================================
    # 🚀 สร้าง DataLoader สำหรับทั้ง train และ val
    # ===============================================================
    # DataLoader จะจัด batch, shuffle และโหลดภาพแบบขนาน
    # เพื่อให้การเทรนเร็วขึ้นและประหยัดหน่วยความจำ
    train_loader = DataLoader(
        train_subset,             # ข้อมูลชุดฝึก
        batch_size=batch_size,    # จำนวนภาพต่อ batch
        shuffle=True,             # สุ่มลำดับภาพในแต่ละ epoch
        num_workers=num_workers,  # ใช้หลาย process เพื่อ preload
        pin_memory=True,          # ช่วยเพิ่มความเร็วบน GPU
    )

    val_loader = DataLoader(
        val_subset,               # ข้อมูลชุดตรวจสอบ
        batch_size=batch_size,
        shuffle=False,            # validation ต้องคงลำดับเพื่อ reproducibility
        num_workers=num_workers,
        pin_memory=True,
    )

    # ส่งกลับทั้ง train_loader, val_loader และ dataset เดิม (ใช้ดู class-to-index ได้)
    return train_loader, val_loader, full_dataset


# ===============================================================
# 🧭 FINAL SUMMARY (สรุปภาพรวมของสคริปต์)
# ===============================================================
# 🎯 จุดประสงค์:
#   เตรียมข้อมูล (Dataset) สำหรับโมเดล Elephant ReID ให้พร้อมเทรน
#
# 📦 การทำงาน:
#   1. โหลดภาพช้างจากโฟลเดอร์ (ImageFolder)
#   2. สร้างชุด train/validation ด้วย random_split
#   3. ใส่ transform ที่แตกต่างระหว่าง train (augment เยอะ) และ val (คงที่)
#   4. สร้าง DataLoader ทั้งสองชุด
#
# 🧠 แนวคิดเบื้องหลัง:
#   - ReID (Re-Identification) ต้องให้โมเดลจดจำลักษณะช้างแต่ละตัว
#   - การเพิ่มความหลากหลายของภาพด้วย augmentation
#     จะช่วยให้โมเดลจำ “ลักษณะเฉพาะตัว” ได้ดีกว่า “ท่าทางซ้ำ ๆ”
#   - Validation ต้องใช้ภาพที่ไม่สุ่ม เพื่อให้วัดผลได้ตรงจริง
#
# 💡 ผลลัพธ์สุดท้าย:
#   train_loader → สำหรับเทรนโมเดล (พร้อม augment)
#   val_loader   → สำหรับวัดความแม่นยำ
#   full_dataset → สำหรับเข้าถึงข้อมูล meta เช่น class index
#
# 📊 เปรียบเทียบเชิงภาพ:
#   - train: ช้างโดนหมุน พลิก สีเปลี่ยน เบลอนิดหน่อย → “เรียนรู้ความแตกต่าง”
#   - val: ช้างเดิมไม่แต่ง → “สอบความเข้าใจจริง”
#
# 🔍 สรุปสั้น:
#   “ไฟล์นี้คือโรงเรียนของโมเดล ReID — จัดห้องเรียนให้พร้อมก่อนสอนมันจำช้าง”
# ===============================================================
