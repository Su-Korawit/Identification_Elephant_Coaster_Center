# ===============================================================
# 📁 FILE: src/elephant_vision/infer.py
# ---------------------------------------------------------------
# สคริปต์นี้คือ “ระบบทำนาย (inference)” ของ Elephant Identification
# หน้าที่หลัก:
#   1. ใช้ YOLO ตรวจจับช้างในภาพหรือวิดีโอ
#   2. ใช้โมเดล ReID สร้าง embedding ของช้างแต่ละตัว
#   3. ใช้ FAISS เทียบกับฐานข้อมูลความจำเพื่อบอกว่าช้างตัวไหน
#   4. แสดงผลพร้อมบันทึก log เป็น CSV
# ===============================================================

import sys, os, csv
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# ↑ เพิ่ม path ของ src เพื่อให้ import โมดูลภายในได้

import cv2
import torch
import time
from datetime import datetime
import numpy as np
import faiss
from ultralytics import YOLO          # ใช้ตรวจจับ bounding box ของช้าง
from torchvision import transforms
from elephant_vision.reid_model import ElephantReIDModel
from elephant_vision.enhance import enhance_image
from elephant_vision.transforms import get_infer_transform
from PIL import Image

# ===============================================================
# ⚙️ CONFIGURATION
# ===============================================================
# ตั้งค่าพื้นฐาน เช่น path ของโมเดล, index, threshold, และ output
# BASE_DIR → root ของ project เพื่อให้ path ต่อจากนี้คงที่เสมอ
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
os.chdir(BASE_DIR)

MODEL_PATH = os.path.join(BASE_DIR, "artifacts/models/reid_model.pt")          # โมเดลจำช้าง (ReID)
INDEX_PATH = os.path.join(BASE_DIR, "artifacts/indexes/elephants.index")        # FAISS Index
NAMES_PATH = os.path.join(BASE_DIR, "artifacts/indexes/elephant_names.npy")     # รายชื่อช้าง
YOLO_PATH = os.path.join(BASE_DIR, "yolo11n.pt")                                # YOLO Model สำหรับตรวจช้าง
THRESHOLD = 0.20                                                                 # ค่าระยะที่ถือว่า “ใกล้” พอ
OUTPUT_DIR = os.path.join(BASE_DIR, "artifacts/outputs")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# debug log
print(f"[DEBUG] MODEL_PATH = {MODEL_PATH}")
print(f"[DEBUG] INDEX_PATH = {INDEX_PATH}")
print(f"[DEBUG] CWD = {os.getcwd()}")

# ===============================================================
# 🧩 FEATURE FLAGS (เปิด/ปิดพฤติกรรม)
# ===============================================================
EXPORT_CSV = True                    # บันทึกผลลง CSV
ONLY_UNKNOWN_NOT_LAST = True         # export เฉพาะ unknown ที่ไม่ใช่ folder สุดท้าย
EXPORT_MIS_MATCH = True              # export กรณีชื่อไม่ตรงกับชื่อโฟลเดอร์
BIGGEST_BOX_ONLY = True              # ใช้เฉพาะ bounding box ที่ใหญ่ที่สุด (กรณีมีหลายตัวในภาพ)

CSV_PATH = os.path.join(OUTPUT_DIR, "identification_log.csv")

# ===============================================================
# 🚀 INITIALIZATION
# ===============================================================
# โหลดโมเดล YOLO สำหรับตรวจจับ bounding box ของช้าง
yolo = YOLO(YOLO_PATH)

# โหลดโมเดล ReID สำหรับจำช้าง
reid = ElephantReIDModel().to(DEVICE)
state_dict = torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True)
missing = reid.load_state_dict(state_dict, strict=False)
reid.eval()
print("⚠️ Skipped keys:", missing.missing_keys)

# โหลด FAISS Index (ฐานข้อมูลความจำ)
index = faiss.read_index(INDEX_PATH)
names = np.load(NAMES_PATH)

# โหลด pipeline แปลงภาพ (resize + normalize)
transform = get_infer_transform()

# ===============================================================
# 🧾 สร้าง CSV สำหรับเก็บผลการทำนาย
# ===============================================================
if EXPORT_CSV:
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ImagePath", "DetectedName", "Match%", "Distance", "FolderName", "Note"])


# ===============================================================
# 🧱 ฟังก์ชัน: บันทึกผลลง CSV
# ===============================================================
def log_csv(image_path, name, match, dist, note=""):
    if not EXPORT_CSV:
        return
    folder_name = os.path.basename(os.path.dirname(image_path))
    with open(CSV_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([image_path, name, f"{match:.3f}", f"{dist:.4f}", folder_name, note])


# ===============================================================
# 🧠 ฟังก์ชัน: ตรวจจับและจำช้างในภาพเดียว (frame)
# ===============================================================
def identify_frame(frame, image_path=None):
    results = yolo(frame)             # ใช้ YOLO ตรวจจับช้างในภาพ
    annotated = frame.copy()          # สำเนาภาพเพื่อวาดกล่องทับ

    # รวมทุก bounding box ที่ตรวจเจอ
    all_boxes, all_classes = [], []
    for r in results:
        all_boxes.extend(r.boxes.xyxy.cpu().numpy())  # พิกัดกรอบ
        all_classes.extend(r.boxes.cls.cpu().numpy()) # หมายเลข class

    # ใช้เฉพาะ box ที่ใหญ่สุด (ถ้าเปิด flag)
    if BIGGEST_BOX_ONLY and len(all_boxes) > 0:
        areas = [(b[2]-b[0])*(b[3]-b[1]) for b in all_boxes]
        max_idx = int(np.argmax(areas))
        all_boxes = [all_boxes[max_idx]]
        all_classes = [all_classes[max_idx]]

    # วนลูปผ่านแต่ละ box
    for box, cls in zip(all_boxes, all_classes):
        if int(cls) != 20:  # class 20 = elephant (ใน YOLO COCO class)
            continue

        x1, y1, x2, y2 = map(int, box)
        crop = frame[y1:y2, x1:x2]
        if crop.size == 0:
            continue

        # ปรับภาพให้คมชัดขึ้นก่อนเข้าโมเดล ReID
        crop = enhance_image(crop)

        # แปลง BGR → RGB และเป็น PIL image สำหรับ torchvision
        crop = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        crop = Image.fromarray(crop)

        # แปลงเป็น tensor และ normalize ตามที่โมเดลต้องการ
        img_tensor = transform(crop).unsqueeze(0).to(DEVICE)

        # สร้าง embedding ด้วยโมเดล ReID
        with torch.no_grad():
            embedding = reid(img_tensor).cpu().numpy().astype("float32")

        # ค้นหาช้างที่ใกล้เคียงที่สุดใน FAISS index
        D, I = index.search(embedding, 3)
        dist, idx = D[0][0], I[0][0]

        # คำนวณเปอร์เซ็นต์ความมั่นใจ (match)
        match = max(0, 1 - dist / THRESHOLD) * 100

        # -------------------------------------------------------
        # ตัดสินใจ: ถ้าอยู่ในระยะ THRESHOLD → ถือว่ารู้จัก
        # -------------------------------------------------------
        if dist < THRESHOLD:
            name = names[idx]
            color = (0, 255, 0)
        else:
            name = "Unknown"
            color = (0, 0, 255)

        label = f"{name} ({match:.3f}%)"
        print(f"Detected: {names[idx]} | Match: {match:.3f}% | Distance: {dist:.4f}")

        # ---------- CSV LOG ----------
        if EXPORT_CSV and image_path:
            folder_name = os.path.basename(os.path.dirname(image_path))
            not_last = len(os.listdir(os.path.dirname(image_path))) > 0
            if (ONLY_UNKNOWN_NOT_LAST and name == "Unknown" and not_last) or \
               (EXPORT_MIS_MATCH and name != "Unknown" and name != folder_name):
                note = "Unknown" if name == "Unknown" else f"Mismatch ({folder_name})"
                log_csv(image_path, name, match, dist, note)

        # ---------- วาดผลลัพธ์ลงภาพ ----------
        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        cv2.putText(annotated, label, (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    # คืนภาพ annotate + ชื่อ + ความมั่นใจ
    return annotated, name, match, dist


# ===============================================================
# 🎞️ ฟังก์ชัน: ประมวลผลวิดีโอ (frame-by-frame)
# ===============================================================
def process_video(video_path, output_path):
    cap = cv2.VideoCapture(video_path)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    fps = cap.get(cv2.CAP_PROP_FPS)
    w, h = int(cap.get(3)), int(cap.get(4))
    out = cv2.VideoWriter(output_path, fourcc, fps, (w, h))

    frame_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        annotated = identify_frame(frame)
        out.write(annotated)
        frame_count += 1
        if frame_count % 10 == 0:
            print(f"🖼 Processed {frame_count} frames...")

    cap.release()
    out.release()
    print(f"✅ Done! Saved to {output_path}")


# ===============================================================
# 🖼️ ฟังก์ชัน: ประมวลผลภาพเดี่ยว
# ===============================================================
def process_image(image_path, output_path=None):
    frame = cv2.imread(image_path)
    annotated, name, match, dist = identify_frame(frame, image_path)
    if output_path:
        cv2.imwrite(output_path, annotated)
        print(f"✅ Saved annotated image to {output_path}")
    return name, match, dist


# ===============================================================
# 📂 ฟังก์ชัน: ประมวลผลทั้งโฟลเดอร์
# ===============================================================
def process_folder(folder_path, output_base=OUTPUT_DIR):
    os.makedirs(output_base, exist_ok=True)
    print(f"📁 Starting identification in folder: {folder_path}")

    test_class_id = 1  # นับ folder ทดสอบ

    # เดินทุกโฟลเดอร์ย่อย
    for root, _, files in os.walk(folder_path):
        folder_name = os.path.basename(root)
        image_files = [f for f in files if f.lower().endswith((".jpg", ".jpeg", ".png"))]
        if not image_files:
            continue

        print(f"\n🧩 Processing Test Class: {test_class_id} ({folder_name})")
        print("=" * 60)

        start_time = time.perf_counter()
        start_dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        best_name = "Unknown"
        best_conf = 0.0
        best_dist = 1.0

        # ประมวลผลทุกภาพในโฟลเดอร์
        for file in image_files:
            input_path = os.path.join(root, file)
            rel_path = os.path.relpath(input_path, folder_path)
            out_dir = os.path.join(output_base, os.path.dirname(rel_path))
            os.makedirs(out_dir, exist_ok=True)
            out_path = os.path.join(out_dir, f"identified_{file}")

            try:
                name, match, dist = process_image(input_path, out_path)

                # บันทึกผลที่ดีที่สุดในโฟลเดอร์
                if match > best_conf:
                    best_name = name
                    best_conf = match
                    best_dist = dist

            except Exception as e:
                print(f"❌ Error processing {file}: {e}")

        end_time = time.perf_counter()
        end_dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        elapsed = end_time - start_time

        # สรุปผลของแต่ละโฟลเดอร์
        print("[Prediction Results]")
        print(f"Test Class: {test_class_id}")
        print(f"Predicted: Class: {best_name}")
        print(f"Confidence: {best_conf:.3f}%")
        print(f"Start Time: {start_dt}")
        print(f"End Time:   {end_dt}")
        print(f"Time Elapsed: {elapsed:.3f}(s)")
        print("-" * 60)

        test_class_id += 1

    print("✅ Folder identification completed.")


# ===============================================================
# 🚀 MAIN ENTRY POINT
# ===============================================================
if __name__ == "__main__":
    if len(sys.argv) > 1:
        folder_path = sys.argv[1]
    else:
        folder_path = r"D:\Identification_Elephant_Coaster_Center\Day1_workshop_data_E"
    process_folder(folder_path)


# ===============================================================
# 🧭 FINAL SUMMARY (ภาพรวม)
# ===============================================================
# 🎯 จุดประสงค์:
#   ทำนายว่าช้างในภาพหรือวิดีโอคือใคร ด้วย YOLO + ReID + FAISS
#
# ⚙️ Pipeline การทำงาน:
#   1. YOLO → ตรวจจับ bounding box ของช้าง
#   2. Enhance → ปรับภาพให้คมชัด
#   3. ReID → แปลงภาพเป็น embedding vector
#   4. FAISS → เทียบกับฐานข้อมูลความจำ (index)
#   5. สรุปผล → ชื่อ, ความมั่นใจ, ระยะทาง, บันทึก CSV
#
# 💡 แนวคิด:
#   - YOLO คือ “สายตา” → มองหาช้างในภาพ
#   - ReID คือ “สมองจำหน้า” → สร้างรหัสเฉพาะตัวของช้างแต่ละตัว
#   - FAISS คือ “ความจำ” → ค้นหาว่ารหัสนี้เหมือนใครที่สุด
#
# 🧠 เปรียบเทียบเชิงภาพ:
#   📷 → YOLO → 🐘 crop → ReID → 🔢 vector → FAISS → 🎯 ช้างตัวที่ใช่
#
# 🐘 สรุปสั้น:
#   “นี่คือสายพานการจดจำช้างอัตโนมัติจากภาพหรือวิดีโอ —
#    ระบบที่เห็นช้างแล้วรู้ว่าเป็นใคร พร้อมบันทึกผลไว้ให้วิเคราะห์ต่อได้”
# ===============================================================
