# ===============================================================
# 📁 FILE: src/elephant_vision/reid_model.py
# ---------------------------------------------------------------
# โมเดลนี้คือหัวใจของระบบ “Elephant Re-Identification (ReID)”
# หน้าที่: แปลงภาพช้าง → เป็นเวกเตอร์แทนตัวตน (embedding vector)
# โมเดลนี้คล้ายกับที่ใช้ใน Face Recognition เช่น ArcFace หรือ DeepFace
# ===============================================================

import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F


# ---------------------------------------------------------------
# 🧠 CLASS: ElephantReIDModel
# ---------------------------------------------------------------
# จุดประสงค์ของคลาสนี้คือ:
#   - ใช้ ResNet-18 เป็น backbone สำหรับดึง feature จากภาพช้าง
#   - แปลง feature เป็น embedding vector ที่มีขนาดกำหนดเอง (embedding_dim)
#   - ใช้ classifier เสริมตอนเทรนด้วย softmax (optional)
#
# Output:
#   - ระหว่างเทรน: คืน (embedding, logits)
#   - ระหว่าง infer: คืน embedding อย่างเดียว (ใช้หาความใกล้เคียงใน FAISS)
# ---------------------------------------------------------------
class ElephantReIDModel(nn.Module):
    def __init__(self, embedding_dim=512, num_classes=None, dropout_p=0.5):
        super().__init__()

        # ===========================================================
        # 🧩 1. Backbone: ResNet-18
        # ===========================================================
        # เหตุผล: ResNet-18 มีพารามิเตอร์น้อย (~11.7M) เมื่อเทียบกับ ResNet-50 (~25.6M)
        # ทำให้:
        #   - เทรนเร็วกว่า
        #   - ใช้ GPU น้อยกว่า
        #   - overfit ยากขึ้น (ดีต่อ dataset ขนาดเล็ก เช่นรูปช้าง)
        #
        # weights="IMAGENET1K_V1" → โหลด pretrained weights จาก ImageNet
        # เพื่อเริ่มจากการเห็น “รูปทั่วไป” มาก่อน เช่น texture, edge, pattern
        backbone = models.resnet18(weights="IMAGENET1K_V1")

        # ===========================================================
        # 🧩 2. Feature Extractor
        # ===========================================================
        # ตัด layer สุดท้ายของ ResNet (fc) ออก เพราะเราไม่ต้องการ classifier เดิม
        # เอาแค่ convolution + global average pooling
        #
        # list(backbone.children()) → รายการ layer ทั้งหมดของ resnet18
        #[:-1] → ลบ layer fc สุดท้ายออก
        self.feature_extractor = nn.Sequential(*list(backbone.children())[:-1])

        # in_features = จำนวนช่องที่ออกจาก backbone (512 สำหรับ ResNet-18)
        in_features = backbone.fc.in_features  # ค่านี้สำคัญใช้ต่อกับ Linear ถัดไป

        # ===========================================================
        # 🧩 3. Embedding Layer (Projection Head)
        # ===========================================================
        # หน้าที่: แปลง feature จาก backbone → เป็น embedding vector
        # (คล้าย concept ของ Face Embedding / Siamese Network)
        #
        # โครงสร้าง:
        #   Linear       → ลด/เพิ่มมิติ
        #   BatchNorm1d  → ทำให้ distribution ของ feature คงที่ระหว่าง batch
        #   ReLU         → เพิ่ม non-linearity
        #   Dropout      → ป้องกัน overfitting
        #
        # embedding_dim: มิติของ vector ตัวตน เช่น 512, 256, 128
        self.embedding_layer = nn.Sequential(
            nn.Linear(in_features, embedding_dim),
            nn.BatchNorm1d(embedding_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout_p),
        )

        # ===========================================================
        # 🧩 4. Classifier Layer (Optional)
        # ===========================================================
        # ใช้เฉพาะตอนเทรนแบบ softmax (cross entropy)
        # ถ้าเราระบุ num_classes → เพิ่ม Linear classifier ต่อท้าย
        # ถ้าไม่ระบุ → ใช้เฉพาะ embedding สำหรับ metric learning / FAISS
        self.classifier = None
        if num_classes is not None:
            self.classifier = nn.Linear(embedding_dim, num_classes)

    # ---------------------------------------------------------------
    # 🔁 Forward Pass
    # ---------------------------------------------------------------
    def forward(self, x):
        # x: batch ของภาพ (B, 3, H, W)

        # 1️⃣ ผ่าน CNN backbone → ดึง feature map
        # ผลลัพธ์จะได้ขนาด (B, C, 1, 1) เพราะผ่าน global average pooling แล้ว
        x = self.feature_extractor(x)

        # 2️⃣ flatten ให้เป็นเวกเตอร์ 1 มิติ (B, C)
        x = x.flatten(1)

        # 3️⃣ ผ่าน embedding layer → แปลงให้เป็น embedding_dim (B, 512)
        x = self.embedding_layer(x)

        # 4️⃣ Normalize ด้วย L2 (vector normalization)
        # เหตุผล: ทำให้เวกเตอร์ทุกตัวอยู่บน hypersphere รัศมี = 1
        # เพื่อใช้ metric เช่น cosine similarity หรือ Euclidean distance เทียบได้ยุติธรรม
        emb = F.normalize(x, p=2, dim=1)

        # 5️⃣ ถ้ามี classifier → ส่งต่อเพื่อเทรน softmax ด้วย
        if self.classifier is not None:
            logits = self.classifier(emb)
            return emb, logits  # คืน embedding + logits (ใช้ใน training)

        # ถ้าไม่มี classifier (inference mode) → คืน embedding อย่างเดียว
        return emb


# ===============================================================
# 🧭 FINAL SUMMARY (สรุปภาพรวมของโมเดล)
# ===============================================================
# 🎯 จุดประสงค์:
#   สร้าง "ReID Model" ที่รับภาพช้าง → แปลงเป็นเวกเตอร์แทนตัวตน (embedding)
#
# 🧠 ส่วนประกอบหลัก:
#   1. Backbone (ResNet-18)
#      - ดึง feature จากภาพ เช่น ผิว, รูปร่าง, เงา
#      - ใช้ pretrained weights จาก ImageNet เพื่อเริ่มต้นเร็ว
#
#   2. Embedding Layer
#      - ลด feature ให้กลายเป็นเวกเตอร์ขนาดคงที่
#      - ผ่าน BatchNorm + Dropout → กัน overfitting
#
#   3. L2 Normalization
#      - ทำให้ทุก embedding มีความยาวเท่ากัน
#      - ทำให้สามารถวัดความคล้าย (cosine similarity) ได้ตรงไปตรงมา
#
#   4. Classifier (optional)
#      - ใช้เฉพาะตอนเทรนด้วย softmax (cross entropy loss)
#      - ตัดออกตอน inference เพื่อใช้เฉพาะ embedding
#
# 💡 แนวคิดสำคัญ:
#   - ในระบบ Elephant ReID เราไม่ได้ “จำแนกช้างใหม่” ด้วย softmax
#     แต่ใช้ “ระยะทาง” ระหว่าง embedding (ผ่าน FAISS หรือ cosine)
#   - ดังนั้น embedding ที่ได้จากโมเดลนี้คือตัวแทนทางคณิตศาสตร์ของ “ตัวตนช้าง”
#
# 🔍 เปรียบเทียบกับมนุษย์:
#   - CNN backbone = ตา (เห็นรายละเอียด)
#   - Embedding layer = สมองส่วนจดจำใบหน้า
#   - L2 normalize = ทำให้จำได้ในมาตรฐานเดียวกัน
#
# 🧩 สรุปสั้น:
#   “โมเดลนี้คือเครื่องสแกน DNA ของช้าง — ป้อนภาพเข้าไป ได้รหัสตัวตนออกมา”
# ===============================================================
