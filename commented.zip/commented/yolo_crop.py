# ===============================================================
# 📁 FILE: src/elephant_vision/yolo_crop.py
# ---------------------------------------------------------------
# หน้าที่ของสคริปต์นี้คือ "แยกช้างออกจากทุก input ที่โยนเข้ามา"
# ไม่ว่าจะเป็น: โฟลเดอร์ใหญ่, โฟลเดอร์ภาพเดี่ยว, หรือวิดีโอ
# โดยใช้ YOLO ตรวจจับช้าง → ครอบเฉพาะบริเวณนั้น
# → ตรวจว่าภาพเบลอไหม → ปรับคุณภาพ → เซฟไว้ใน dataset
# ใช้เป็นขั้นตอนเตรียมข้อมูลก่อนเทรนโมเดล ReID (จำแนกช้างรายตัว)
# ===============================================================


# ===============================
# 🧩 IMPORT SECTION
# ===============================
import os                   # จัดการไฟล์และไดเรกทอรี เช่น ตรวจสอบว่า path เป็นไฟล์หรือโฟลเดอร์, สร้างโฟลเดอร์ใหม่
import cv2                  # ไลบรารีประมวลผลภาพ ใช้เปิด, อ่าน, ครอบ, บันทึกภาพ และจัดการเฟรมวิดีโอ
from ultralytics import YOLO  # ดึงโมเดล YOLO (You Only Look Once) สำหรับตรวจจับวัตถุในภาพ
from .enhance import enhance_image, is_blurry  # ฟังก์ชันภายในโปรเจ็กต์: ปรับคุณภาพภาพ และตรวจว่าเบลอไหม

# 🧠 หมายเหตุ: import แบบนี้ช่วยแยก concern ชัดเจน — YOLO สำหรับการตรวจจับ, cv2 สำหรับการประมวลผล,
# enhance_image สำหรับ post-process, ส่วน is_blurry ช่วยคัดภาพไม่ดีออก


# ===============================
# 🚀 MAIN FUNCTION
# ===============================
def process_input(input_path, elephant_name=None, frame_stride=5):
    """
    ฟังก์ชันหลักของระบบตัดต่อช้าง 🐘
    ---------------------------------------------------------
    input_path: path ของ input (อาจเป็นภาพ, โฟลเดอร์, หรือวิดีโอ)
    elephant_name: ชื่อช้าง (ถ้าไม่ใส่จะเดาจากชื่อไฟล์หรือชื่อโฟลเดอร์)
    frame_stride: จำนวนภาพ/เฟรมที่ข้าม เช่น 5 = เก็บทุก 5 เฟรม
    ---------------------------------------------------------
    ทำงานครอบจักรวาล: ตรวจว่าคืออะไร แล้วจัดการตามประเภทนั้น
    """

    # โหลดโมเดล YOLO (รุ่น 11n = nano model → น้ำหนักเบาและเร็ว)
    # เหมาะสำหรับ preprocessing เพราะไม่ต้องใช้ความแม่นสูงสุด
    model = YOLO("yolo11n.pt")

    # path พื้นฐานที่ใช้เก็บ output (dataset สำหรับ ReID)
    base_output = "artifacts/datasets/reid/train"

    # สร้างโฟลเดอร์เป้าหมายไว้ก่อน (ถ้ายังไม่มี)
    # exist_ok=True ป้องกัน error ถ้าโฟลเดอร์นั้นมีอยู่แล้ว
    os.makedirs(base_output, exist_ok=True)


    # ===============================================================
    # 🧩 CASE 1: ถ้า input เป็น “โฟลเดอร์ใหญ่ที่มีหลายช้าง”
    # เช่น D:/datasets/elephants/
    #     ├── aiko/
    #     ├── nongwan/
    #     └── ploy/
    # ===============================================================
    if os.path.isdir(input_path):  # ตรวจว่าคือ directory ไหม
        # ดึง subfolder ทั้งหมดภายใน เช่น ["aiko", "nongwan", "ploy"]
        subfolders = [
            os.path.join(input_path, d)
            for d in os.listdir(input_path)
            if os.path.isdir(os.path.join(input_path, d))
        ]

        # ถ้ามี subfolder อย่างน้อย 1 ตัว แสดงว่าเป็นโฟลเดอร์รวม
        if len(subfolders) > 0:
            print(f"📁 Detected {len(subfolders)} subfolders. Processing all elephants...")

            # วนประมวลผลช้างแต่ละตัว
            for sub in subfolders:
                name = os.path.basename(sub)  # ชื่อช้าง = ชื่อโฟลเดอร์
                print(f"\n🐘 Processing elephant: {name}")

                # 🔁 Recursive call — เรียกฟังก์ชันนี้ซ้ำเพื่อประมวลผล subfolder
                process_input(sub, name, frame_stride=frame_stride)

            print("✅ All subfolders processed successfully.")
            return  # เสร็จแล้ว ออกจากฟังก์ชัน (ไม่ต้องทำส่วนต่อไป)


    # ===============================================================
    # 🧩 CASE 2: ถ้า input เป็น “โฟลเดอร์ภาพของช้างตัวเดียว”
    # เช่น D:/datasets/elephants/aiko/
    # ===============================================================
    if os.path.isdir(input_path):  # ตรวจสอบอีกครั้งว่ายังเป็น directory
        # ถ้าไม่ได้ระบุชื่อช้าง ให้ใช้ชื่อโฟลเดอร์แทน
        if elephant_name is None:
            elephant_name = os.path.basename(os.path.normpath(input_path))

        # สร้างโฟลเดอร์ปลายทางสำหรับภาพของช้างตัวนี้
        output_dir = os.path.join(base_output, elephant_name)
        os.makedirs(output_dir, exist_ok=True)

        # ดึงไฟล์ภาพทั้งหมดในโฟลเดอร์ (กรองเฉพาะ jpg/png/jpeg)
        image_files = [
            f for f in os.listdir(input_path)
            if f.lower().endswith((".jpg", ".png", ".jpeg"))
        ]

        saved = 0                  # ตัวนับภาพที่บันทึกได้
        skip_stride = frame_stride  # ใช้ข้ามทุก N ภาพ เช่น 5

        # วนลูปอ่านภาพทั้งหมดเรียงลำดับชื่อไฟล์
        for i, img_name in enumerate(sorted(image_files)):
            # 🔹 ข้ามภาพเพื่อไม่เก็บซ้ำมากเกิน (ทุก stride)
            if i % skip_stride != 0:
                continue

            # โหลดภาพจาก path เต็ม
            img_path = os.path.join(input_path, img_name)
            frame = cv2.imread(img_path)

            # ถ้าอ่านไม่ได้ (เช่นไฟล์เสีย) ก็ข้าม
            if frame is None:
                continue

            # รัน YOLO ตรวจจับวัตถุในภาพ
            # verbose=False ปิด log เพื่อลดข้อความรกใน console
            results = model(frame, verbose=False)

            # ดึง bounding boxes ทั้งหมดในภาพ (รูปแบบ [x1, y1, x2, y2])
            boxes = results[0].boxes.xyxy.cpu().numpy()

            # ถ้าไม่มีวัตถุเลย → ข้าม
            if len(boxes) == 0:
                continue

            # คำนวณพื้นที่แต่ละกล่องเพื่อเลือกกล่องใหญ่สุด
            # สมมุติว่าช้างตัวหลักในภาพมักใหญ่ที่สุด
            areas = [(b[2] - b[0]) * (b[3] - b[1]) for b in boxes]
            max_idx = int(areas.index(max(areas)))

            # แปลงพิกัดจาก float → int เพื่อใช้ตัดภาพ
            x1, y1, x2, y2 = map(int, boxes[max_idx][:4])

            # ครอบภาพเฉพาะส่วนของช้าง
            crop = frame[y1:y2, x1:x2]

            # ถ้าครอบแล้วว่างเปล่าหรือเบลอ → ทิ้ง
            if crop.size == 0 or is_blurry(crop):
                continue

            # ปรับคุณภาพภาพ (เช่น sharpen, normalize, เพิ่ม contrast)
            enhanced = enhance_image(crop)

            # สร้างชื่อไฟล์ เช่น aiko_0005.jpg (เรียงลำดับ 4 หลัก)
            save_path = os.path.join(output_dir, f"{elephant_name}_{i:04d}.jpg")

            # บันทึกภาพลง disk
            cv2.imwrite(save_path, enhanced)
            saved += 1  # เพิ่มตัวนับภาพที่เซฟได้

        # รายงานผลสรุปเมื่อทำเสร็จ
        print(f"✅ Saved {saved} images (every {skip_stride}th) from {input_path} → {output_dir}")
        return  # เสร็จแล้วออกจากฟังก์ชัน


    # ===============================================================
    # 🧩 CASE 3: ถ้า input เป็น “วิดีโอ”
    # ===============================================================
    if input_path.lower().endswith((".mp4", ".avi", ".mov")):
        # ถ้าไม่มีชื่อช้าง ให้ใช้ชื่อไฟล์วิดีโอแทน เช่น “elephant_walk.mp4” → “elephant_walk”
        if elephant_name is None:
            elephant_name = os.path.splitext(os.path.basename(input_path))[0]

        # สร้างโฟลเดอร์เก็บภาพของช้างตัวนี้
        output_dir = os.path.join(base_output, elephant_name)
        os.makedirs(output_dir, exist_ok=True)

        # เปิดวิดีโอด้วย OpenCV
        cap = cv2.VideoCapture(input_path)

        frame_idx = 0  # ตัวนับเฟรม (ใช้ทั้งชื่อไฟล์และ stride)
        saved = 0      # ตัวนับจำนวนภาพที่บันทึกแล้ว

        # วนลูปอ่านวิดีโอเฟรมต่อเฟรม
        while True:
            ret, frame = cap.read()  # อ่านเฟรมถัดไป
            if not ret:              # ถ้าอ่านไม่ได้ (จบวิดีโอ)
                break

            # 🔹 ข้ามเฟรมตาม stride เช่น ทุก 5 เฟรม
            if frame_idx % frame_stride != 0:
                frame_idx += 1
                continue

            # ตรวจจับช้างในเฟรมปัจจุบัน
            results = model(frame, verbose=False)
            boxes = results[0].boxes.xyxy.cpu().numpy()

            # ถ้าไม่พบช้าง → ข้าม
            if len(boxes) == 0:
                frame_idx += 1
                continue

            # เลือกกล่องใหญ่ที่สุด (เพราะช้างตัวหลักมักกินพื้นที่มากสุด)
            areas = [(b[2] - b[0]) * (b[3] - b[1]) for b in boxes]
            max_idx = int(areas.index(max(areas)))
            x1, y1, x2, y2 = map(int, boxes[max_idx][:4])

            # ครอบเฉพาะบริเวณช้าง
            crop = frame[y1:y2, x1:x2]

            # ถ้าครอบแล้วว่างหรือเบลอ → ข้าม
            if crop.size == 0 or is_blurry(crop):
                frame_idx += 1
                continue

            # ปรับคุณภาพภาพ
            enhanced = enhance_image(crop)

            # ตั้งชื่อไฟล์จากลำดับเฟรม เช่น elephant_0045.jpg
            save_path = os.path.join(output_dir, f"{elephant_name}_{frame_idx:04d}.jpg")
            cv2.imwrite(save_path, enhanced)

            saved += 1
            frame_idx += 1  # ไปเฟรมถัดไป

        # ปิดไฟล์วิดีโอหลังใช้งานเสร็จ
        cap.release()

        # แสดงผลรวมทั้งหมดของวิดีโอนี้
        print(f"✅ Saved {saved} frames (every {frame_stride}th) from video {input_path} → {output_dir}")


# ===============================================================
# 🧭 FINAL SUMMARY (สรุปภาพรวมของโค้ดทั้งหมด)
# ===============================================================
# โค้ดนี้เป็น “ระบบจัดเตรียมข้อมูลช้างอัตโนมัติ” เพื่อใช้สร้าง Dataset
# สำหรับโมเดล ReID (จำแนกตัวช้างแต่ละตัว)
#
# ✅ รองรับ input หลายประเภท:
#   - โฟลเดอร์ใหญ่ที่มีหลายช้าง → ประมวลผลซ้ำแบบ recursive
#   - โฟลเดอร์ภาพเดี่ยว → ตัดเฉพาะช้างทีละภาพ
#   - วิดีโอ → แยกเฟรมออกมาเป็นภาพนิ่งพร้อมครอบเฉพาะช้าง
#
# ✅ ขั้นตอนภายใน:
#   1. ตรวจจับช้างด้วย YOLO
#   2. เลือก bounding box ที่ใหญ่สุด (มักเป็นช้างตัวหลัก)
#   3. ครอบเฉพาะส่วนช้าง
#   4. ตรวจสอบความเบลอด้วย is_blurry() → กรองภาพไม่ดีออก
#   5. ปรับคุณภาพด้วย enhance_image() → ทำให้ภาพชัดขึ้น
#   6. เซฟลงใน dataset ที่มีโครงสร้างชัดเจน / พร้อมเทรน
#
# ✅ จุดแข็งของระบบ:
#   - ปลอดภัยจากข้อมูลซ้ำซ้อนด้วย stride
#   - ไม่ต้องพึ่งคนจัดภาพทีละไฟล์
#   - ใช้โมเดลตรวจจับอัตโนมัติ ลดเวลาเตรียม dataset หลายเท่า
#   - ออกแบบให้ modular: เปลี่ยน enhance หรือ detector ได้ง่าย
#
# 🎯 สรุปสั้น ๆ:
#   “มันคือสายพานผลิตภาพช้างสะอาด คุณภาพดี
#    เพื่อป้อนให้โมเดลจำแนกตัวช้างเรียนรู้ได้อย่างมีประสิทธิภาพ”
