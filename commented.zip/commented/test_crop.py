# ===============================================================
# 📁 FILE: src/elephant_vision/test_crop.py
# ---------------------------------------------------------------
# สคริปต์นี้เป็น “ตัวทดสอบระบบครอบช้าง (YOLO crop test runner)”
# ใช้รันฟังก์ชัน process_input() จากโมดูล yolo_crop.py
# โดยสามารถใส่ path เป็น argument หรือกำหนดค่าในโค้ดได้เลย
# ===============================================================

import sys, os
# ---------------------------------------------------------------
# เพิ่ม path ของโฟลเดอร์หลัก (src) เข้าไปใน sys.path
# ---------------------------------------------------------------
# ปกติ Python จะมองหา module เฉพาะในโฟลเดอร์ที่รันอยู่เท่านั้น
# แต่ในที่นี้เราต้องการ import โมดูลจากโฟลเดอร์ 'elephant_vision'
# ซึ่งอยู่ระดับบนสุดของ path ปัจจุบัน
# 
# ตัวอย่างโครงสร้าง:
#   src/
#   ├── elephant_vision/
#   │   ├── yolo_crop.py
#   │   ├── enhance.py
#   │   └── test_crop.py  ← (ไฟล์นี้)
#
# ดังนั้นเราจึงต้องเพิ่ม path “src” เข้าไปก่อน เพื่อให้ Python หาเจอ
#
# อธิบายการทำงาน:
# - os.path.dirname(__file__)  → path ของไฟล์ปัจจุบัน (test_crop.py)
# - os.path.join(..., '..')    → ขึ้นไป 1 ระดับ (src)
# - os.path.abspath(...)       → แปลงเป็น path สมบูรณ์
# - sys.path.append(...)       → เพิ่ม path นี้เข้าไปใน Python path list
#
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


# ---------------------------------------------------------------
# import ฟังก์ชันหลัก process_input() จาก yolo_crop.py
# ---------------------------------------------------------------
# หลังจากเพิ่ม path แล้ว เราก็สามารถ import จากแพ็กเกจ elephant_vision ได้ตรง ๆ
# process_input คือฟังก์ชันหลักที่:
#   - ตรวจจับช้างด้วย YOLO
#   - ครอบภาพ
#   - กรองภาพเบลอ
#   - ปรับคุณภาพ
#   - บันทึกลง dataset
#
from elephant_vision.yolo_crop import process_input


# ---------------------------------------------------------------
# 🧩 เวอร์ชันแรก (ถูกคอมเมนต์ไว้)
# ---------------------------------------------------------------
# ฟังก์ชันนี้คือแบบ “hardcoded test” — ใช้ path ตายตัว
# เหมาะกับตอนพัฒนาเบื้องต้นหรือ debug แบบเร็ว
# ---------------------------------------------------------------
# if __name__ == "__main__":
#     input_path = r"D:\Identification_Elephant_Coaster_Center\Day1_workshop_data_E"
#     print(f"Processing {input_path}")
#     process_input(input_path, elephant_name=None, frame_stride=5)
#     print("✅ Test finished.")
#
# ✅ อธิบายการทำงาน:
#   - `if __name__ == "__main__":` → หมายความว่า code นี้จะรันเฉพาะเมื่อเรียกไฟล์โดยตรง
#     (เช่น `python test_crop.py`) ไม่รันเมื่อ import เป็นโมดูล
#   - `input_path = ...` → ระบุ path ของ dataset ที่ต้องการทดสอบ (แบบคงที่)
#   - `print(...)` → แสดงข้อความว่าเริ่ม process
#   - `process_input(...)` → เรียกฟังก์ชันจริงจาก yolo_crop.py
#   - `frame_stride=5` → ข้ามทุก 5 เฟรม/ภาพ (ลดการประมวลผลซ้ำ)
#   - `print("✅ Test finished.")` → แสดงข้อความเมื่อเสร็จสิ้น
#
# จุดเด่นของเวอร์ชันนี้: เหมาะกับการ debug local test อย่างรวดเร็ว  
# ข้อเสีย: ต้องแก้ path ในโค้ดเองทุกครั้งเมื่อเปลี่ยน dataset


# ---------------------------------------------------------------
# 🧩 เวอร์ชันที่สอง (ใช้งานจริง)
# ---------------------------------------------------------------
# ส่วนนี้เป็นเวอร์ชันที่ “ยืดหยุ่นกว่า” — สามารถส่ง path ผ่าน command-line argument ได้
# ---------------------------------------------------------------
if __name__ == "__main__":  # ทำงานเมื่อไฟล์นี้ถูกรันโดยตรง เช่น python test_crop.py <path>
    # ตรวจว่าผู้ใช้ส่ง argument มาทางบรรทัดคำสั่งไหม
    if len(sys.argv) > 1:
        # ถ้ามี argument เช่น: python test_crop.py D:\elephants\aiko
        # sys.argv[1] จะเป็น path ที่ใส่มา
        input_path = sys.argv[1]
    else:
        # ถ้าไม่ใส่ argument จะใช้ path ดีฟอลต์
        input_path = r"D:\Identification_Elephant_Coaster_Center\Day1_workshop_data_E"

    # แสดงว่ากำลังเริ่มประมวลผลที่ path ไหน
    print(f"Processing {input_path}")

    # เรียกใช้ process_input() จาก yolo_crop.py
    # elephant_name=None หมายถึงให้เดาชื่อจากชื่อโฟลเดอร์เอง
    # frame_stride=5 → ประมวลผลทุก 5 ภาพ (ลดโหลด CPU/GPU)
    process_input(input_path, elephant_name=None, frame_stride=5)

    # แสดงผลว่าทดสอบเสร็จแล้ว
    print("✅ Test finished.")


# ===============================================================
# 🧭 FINAL SUMMARY (สรุปภาพรวมของสคริปต์)
# ===============================================================
# 🎯 จุดประสงค์:
#   - ใช้เป็น “สคริปต์ทดสอบ” ฟังก์ชัน process_input() ของระบบ Elephant Vision
#   - ออกแบบมาให้รันได้ทั้งแบบ hardcode และผ่าน argument
#
# 🔧 การทำงาน:
#   1. เพิ่ม path ของ src เข้า sys.path เพื่อให้ Python หาโมดูล elephant_vision ได้
#   2. import ฟังก์ชัน process_input จาก yolo_crop.py
#   3. ถ้ามี argument → ใช้ path นั้น, ถ้าไม่มี → ใช้ path ค่าเริ่มต้น
#   4. เรียก process_input() เพื่อครอบและปรับภาพช้าง
#   5. แสดงผลเมื่อเสร็จสิ้น
#
# 💡 ประโยชน์:
#   - ใช้ตรวจว่าระบบทำงานครบไหม โดยไม่ต้องเปิด UI หรือเขียน pipeline ใหญ่
#   - ใช้ test dataset จริงหรือ video ได้ทันที
#   - ยืดหยุ่นกับ environment (local, server, Colab)
#
# 🔍 สรุปสั้น:
#   “ไฟล์นี้คือรีโมตคอนโทรลเล็ก ๆ ที่เรียกเครื่องจักร YOLO crop ให้ทำงานทดสอบ”
# ===============================================================
