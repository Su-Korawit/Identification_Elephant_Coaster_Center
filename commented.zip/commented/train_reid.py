# ===============================================================
# 📁 FILE: src/elephant_vision/train_reid.py
# ---------------------------------------------------------------
# หน้าที่ของสคริปต์นี้: ฝึกโมเดลจำช้างรายตัว (Elephant ReID)
# โดยใช้ข้อมูลที่เตรียมไว้ใน artifacts/datasets/reid/train
# กระบวนการหลัก:
#   1. โหลด dataset (train/val)
#   2. สร้างโมเดล
#   3. เทรนหลาย epoch → log loss / accuracy
#   4. ใช้ early stopping, lr scheduler
#   5. เซฟโมเดลและกราฟผลลัพธ์
# ===============================================================

import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# ↑ เพิ่ม path ของ src เข้า sys.path เพื่อให้ import โมดูลภายในได้
#   เช่น elephant_vision.reid_model หรือ reid_dataset


import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# import ส่วนประกอบสำคัญของระบบ
from elephant_vision.reid_model import ElephantReIDModel
from elephant_vision.reid_dataset import get_reid_dataloaders


# ---------------------------------------------------------------
# 🧩 ฟังก์ชันหลัก: train_reid()
# ---------------------------------------------------------------
def train_reid(
    data_dir="artifacts/datasets/reid/train",  # path dataset ที่เตรียมไว้
    epochs=3,                                 # จำนวนรอบการเทรน
    batch_size=4,                             # ขนาด batch (เล็กเพื่อใช้ GPU น้อย)
    lr=1e-4,                                  # learning rate
    weight_decay=1e-4,                        # L2 regularization
    patience=5,                               # early stopping ถ้า val loss ไม่ดีขึ้นหลายรอบ
):

    # -----------------------------------------------------------
    # ⚙️ กำหนดอุปกรณ์ประมวลผล (GPU ถ้ามี)
    # -----------------------------------------------------------
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # -----------------------------------------------------------
    # 📦 โหลด dataset และสร้าง DataLoader
    # -----------------------------------------------------------
    # ฟังก์ชัน get_reid_dataloaders() จะ:
    #   - โหลดภาพจากแต่ละโฟลเดอร์ (ช้างแต่ละตัว)
    #   - สร้าง train/val split
    #   - ใส่ augmentation ให้ชุด train
    #   - คืน DataLoader พร้อม dataset เต็ม
    train_loader, val_loader, full_dataset = get_reid_dataloaders(
        data_dir=data_dir,
        batch_size=batch_size,
        num_workers=2,
        val_ratio=0.2,  # ใช้ 20% ของข้อมูลสำหรับ validation
    )

    # -----------------------------------------------------------
    # 🐘 ดูจำนวน class (จำนวนตัวช้าง)
    # -----------------------------------------------------------
    num_classes = len(full_dataset.classes)
    print(f"📦 Found {num_classes} elephant identities: {full_dataset.classes}")

    # -----------------------------------------------------------
    # 🧠 สร้างโมเดลจำช้าง (ReID model)
    # -----------------------------------------------------------
    model = ElephantReIDModel(num_classes=num_classes).to(device)
    #   - ใช้ ResNet-18 เป็น backbone
    #   - มี classifier ต่อท้ายเพื่อเทรนแบบ softmax

    # -----------------------------------------------------------
    # ⚖️ Loss function
    # -----------------------------------------------------------
    # ใช้ CrossEntropyLoss เหมาะกับการจำแนกหลายคลาส
    criterion = nn.CrossEntropyLoss()

    # -----------------------------------------------------------
    # 🧰 Optimizer
    # -----------------------------------------------------------
    # AdamW เป็นเวอร์ชันปรับปรุงของ Adam ที่มี weight decay จริง
    # ใช้ weight_decay เป็น regularization เพื่อลด overfitting
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    # -----------------------------------------------------------
    # 📉 Learning Rate Scheduler
    # -----------------------------------------------------------
    # ReduceLROnPlateau → ถ้า val loss ไม่ดีขึ้นหลาย epoch ให้ลด lr ลงครึ่งหนึ่ง
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=2, verbose=True
    )

    # -----------------------------------------------------------
    # 📊 ตัวแปรเก็บประวัติ (ใช้ plot ภายหลัง)
    # -----------------------------------------------------------
    history = {
        "train_loss": [],
        "val_loss": [],
        "train_acc": [],
        "val_acc": [],
    }

    # ตัวแปรควบคุม early stopping
    best_val_loss = float("inf")
    bad_epochs = 0
    best_state_dict = None

    # ===========================================================
    # 🚀 เริ่มเทรนทีละ epoch
    # ===========================================================
    for epoch in range(epochs):

        # =========================
        # 🔁 TRAIN PHASE
        # =========================
        model.train()  # เปิดโหมดเทรน (เปิด dropout, batchnorm อัปเดตค่า)
        total_loss, correct, total = 0.0, 0, 0

        for imgs, labels in train_loader:
            imgs, labels = imgs.to(device), labels.to(device)

            # Forward ผ่านโมเดล
            _, logits = model(imgs)  # logits คือผล softmax classifier
            loss = criterion(logits, labels)

            # Backpropagation
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # เก็บสถิติ loss และ accuracy
            total_loss += loss.item()
            preds = torch.argmax(logits, dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

        avg_train_loss = total_loss / len(train_loader)
        train_acc = correct / total * 100.0

        # =========================
        # 🧪 VALIDATION PHASE
        # =========================
        model.eval()  # ปิด dropout / batchnorm update
        val_total_loss, val_correct, val_total = 0.0, 0, 0

        with torch.no_grad():  # ไม่เก็บ gradient เพื่อลดหน่วยความจำ
            for imgs, labels in val_loader:
                imgs, labels = imgs.to(device), labels.to(device)
                _, logits = model(imgs)
                loss = criterion(logits, labels)

                val_total_loss += loss.item()
                preds = torch.argmax(logits, dim=1)
                val_correct += (preds == labels).sum().item()
                val_total += labels.size(0)

        avg_val_loss = val_total_loss / len(val_loader)
        val_acc = val_correct / val_total * 100.0

        # =========================
        # 💾 LOGGING (บันทึกผลในแต่ละ epoch)
        # =========================
        history["train_loss"].append(avg_train_loss)
        history["val_loss"].append(avg_val_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)

        print(f"Epoch [{epoch+1}/{epochs}] "
              f"- Train Loss: {avg_train_loss:.4f} | Train Acc: {train_acc:.2f}% "
              f"- Val Loss: {avg_val_loss:.4f} | Val Acc: {val_acc:.2f}%")

        # =========================
        # 📉 ปรับ Learning Rate
        # =========================
        scheduler.step(avg_val_loss)

        # =========================
        # 🛑 EARLY STOPPING
        # =========================
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            best_state_dict = model.state_dict()  # เก็บโมเดลที่ดีที่สุดไว้
            bad_epochs = 0
        else:
            bad_epochs += 1
            if bad_epochs >= patience:
                print("🛑 Early stopping triggered.")  # หยุดก่อนถ้าไม่พัฒนา
                break

    # ===========================================================
    # 💾 SAVE BEST MODEL
    # ===========================================================
    os.makedirs("artifacts/models", exist_ok=True)
    best_model_path = "artifacts/models/reid_model.pt"
    torch.save(best_state_dict, best_model_path)
    print(f"✅ Best model saved to {best_model_path}")

    # ===========================================================
    # 📊 PLOT TRAINING CURVES
    # ===========================================================
    os.makedirs("artifacts/plots", exist_ok=True)
    plt.figure(figsize=(10,4))

    # 🔹 Plot Loss
    plt.subplot(1,2,1)
    plt.plot(history["train_loss"], label="Train Loss")
    plt.plot(history["val_loss"], label="Val Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Loss (CrossEntropy)")
    plt.legend()

    # 🔹 Plot Accuracy
    plt.subplot(1,2,2)
    plt.plot(history["train_acc"], label="Train Acc")
    plt.plot(history["val_acc"], label="Val Acc")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy (%)")
    plt.title("ID Classification Accuracy")
    plt.legend()

    # เซฟกราฟไว้
    plot_path = "artifacts/plots/reid_training_curves.png"
    plt.tight_layout()
    plt.savefig(plot_path)
    print(f"📊 Saved training plot to {plot_path}")
    plt.show()


# ===============================================================
# 🚀 ENTRY POINT (main)
# ===============================================================
# รันเทรนเมื่อเรียกไฟล์นี้โดยตรง
if __name__ == "__main__":
    train_reid()


# ===============================================================
# 🧭 FINAL SUMMARY (สรุปภาพรวมของสคริปต์)
# ===============================================================
# 🎯 จุดประสงค์:
#   ฝึกโมเดล Elephant ReID ด้วยข้อมูลจาก dataset ที่เตรียมไว้
#
# ⚙️ ขั้นตอนการทำงาน:
#   1. โหลด train/val dataset ด้วย augmentation
#   2. สร้างโมเดล (ResNet-18 + embedding layer + classifier)
#   3. เทรนหลาย epoch วัด loss/accuracy
#   4. ใช้ early stopping ป้องกัน overfit
#   5. ปรับ learning rate อัตโนมัติเมื่อไม่ดีขึ้น
#   6. เซฟ best model + กราฟผลเทรนไว้ใน artifacts/
#
# 💡 จุดเด่น:
#   - ใช้ AdamW + weight decay → ควบคุม overfit
#   - ใช้ ReduceLROnPlateau → ลด lr อัตโนมัติ
#   - ใช้ Early Stopping → ประหยัดเวลาเทรน
#   - เซฟโมเดลที่ดีที่สุด → พร้อมนำไปใช้งานจริง (inference)
#
# 🧠 ความหมายเชิงระบบ:
#   โค้ดนี้คือ “ครูฝึก” ของโมเดลจำช้าง
#   มันสอนให้โมเดลรู้ว่า “ภาพลายงาแบบนี้คือตัว Aiko”,
#   “รอยแผลแบบนี้คือตัว Ploy” ฯลฯ
#
# 🔍 เปรียบเทียบให้เห็นภาพ:
#   - reid_dataset.py = ห้องเรียน (ข้อมูล)
#   - reid_model.py   = สมอง (โมเดล)
#   - train_reid.py   = ครูฝึก (กระบวนการเรียนรู้)
#
# 📊 สรุปสั้น:
#   “นี่คือสคริปต์ที่ทำให้คอมพิวเตอร์ ‘จำหน้าช้าง’ ได้จริง”
# ===============================================================
