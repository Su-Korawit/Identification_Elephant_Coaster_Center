import os

# Path ของโปรเจกต์หลัก (root directory)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

MODEL_PATH = "yolo11n-seg.pt"
OUTPUT_BASE = os.path.join(PROJECT_ROOT, "artifacts", "datasets", "reid", "train")
FRAME_STRIDE = 2
RESIZE_FX = 0.5
BLUR_THRESHOLD = 100.0
ELEPHANT_CLASS_IDS = [20, 22]
PERSON_CLASS_ID = 0
OVERLAP_THRESHOLD = 0.3

