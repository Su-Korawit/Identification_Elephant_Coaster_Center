# src/elephant_vision/test_crop.py
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from elephant_vision.yolo_crop import process_input

if __name__ == "__main__":
    input_path = r"D:\Identification_Elephant_Coaster_Center\SampleDataset\rain.mp4"
    elephant_name = "Rain"

    print(f"Processing {input_path} for elephant: {elephant_name}")
    process_input(input_path, elephant_name, frame_stride=1)
    print("✅ Test finished.")
