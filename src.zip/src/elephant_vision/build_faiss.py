# src/elephant_vision/build_faiss.py
import sys, os
from xml.parsers.expat import model
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import faiss
import numpy as np
from elephant_vision.reid_model import ElephantReIDModel
from elephant_vision.reid_dataset import get_reid_dataloader
from tqdm import tqdm

def build_faiss_index(
    model_path="artifacts/models/reid_model.pt",
    data_dir="artifacts/datasets/reid/train",
    index_path="artifacts/indexes/elephants.index",
    names_path="artifacts/indexes/elephant_names.npy",
    use_gpu=True
):
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # โหลดโมเดล
    model = ElephantReIDModel(num_classes=None).to(device)
    state_dict = torch.load(model_path, map_location=device)
    missing, unexpected = model.load_state_dict(state_dict, strict=False)
    if unexpected:
        print(f"⚠️ Skipped keys: {unexpected}")
    model.eval()

    # โหลด dataset
    dataloader, dataset = get_reid_dataloader(data_dir, batch_size=16)
    names = dataset.classes
    embeddings, labels = [], []

    print(f"📦 Generating embeddings for {len(dataset)} images...")
    with torch.no_grad():
        for imgs, lbls in tqdm(dataloader):
            imgs = imgs.to(device)
            embed = model(imgs)
            embeddings.append(embed.cpu().numpy())
            labels.extend(lbls.numpy())

    embeddings = np.vstack(embeddings).astype("float32")
    dim = embeddings.shape[1]
    print(f"🧠 Embedding shape: {embeddings.shape}")

    # 🔹 ใช้ IndexHNSWFlat (ดีกว่า FlatL2)
    m = 32  # number of neighbors in the graph (default 32)
    index = faiss.IndexHNSWFlat(dim, m)
    index.hnsw.efConstruction = 64
    index.hnsw.efSearch = 32

    # 🔹 ย้ายไป GPU ถ้ามี CUDA และอนุญาต
    if use_gpu and torch.cuda.is_available() and hasattr(faiss, "StandardGpuResources"):
        res = faiss.StandardGpuResources()
        index = faiss.index_cpu_to_gpu(res, 0, index)
        print("⚡ Using FAISS GPU acceleration")

    # เพิ่มข้อมูลลง index
    index.add(embeddings)

    # # 🔹 เซฟ index (ย้ายกลับ CPU ก่อนบันทึก)
    # if isinstance(index, faiss.GpuIndex):
    #     index = faiss.index_gpu_to_cpu(index)
    # 🔹 เซฟ index (ตรวจว่ามี GpuIndex หรือไม่ก่อน)
    if hasattr(faiss, "GpuIndex") and isinstance(index, faiss.GpuIndex):
        index = faiss.index_gpu_to_cpu(index)
    else:
        print("⚠️ FAISS GPU not detected — using CPU index instead.")

    os.makedirs(os.path.dirname(index_path), exist_ok=True)
    faiss.write_index(index, index_path)
    np.save(names_path, np.array([names[i] for i in labels]))

    print(f"✅ Index saved: {index_path}")
    print(f"✅ Names saved: {names_path}")
    print(f"📈 Total vectors: {index.ntotal}, dimension: {dim}")

if __name__ == "__main__":
    build_faiss_index()
